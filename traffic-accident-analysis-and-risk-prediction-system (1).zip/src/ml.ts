import { AccidentRecord, PredictionInput, PredictionResult } from './types';

// Helper to categorize hour into Time of Day
export function getTimeOfDay(timeStr: string): 'Morning' | 'Afternoon' | 'Evening' | 'Night' {
  if (!timeStr) return 'Afternoon';
  const hour = parseInt(timeStr.split(':')[0], 10);
  if (isNaN(hour)) return 'Afternoon';
  if (hour >= 5 && hour < 12) return 'Morning';
  if (hour >= 12 && hour < 17) return 'Afternoon';
  if (hour >= 17 && hour < 21) return 'Evening';
  return 'Night';
}

// Convert severity to risk
export function severityToRisk(severity: 'Fatal' | 'Severe' | 'Minor'): 'Low' | 'Medium' | 'High' {
  if (severity === 'Fatal') return 'High';
  if (severity === 'Severe') return 'Medium';
  return 'Low';
}

// Map categorical values to indices for easy classification
const WEATHER_CATEGORIES = ['Clear', 'Rain', 'Fog', 'Cloudy', 'Mist'];
const ROAD_CATEGORIES = ['Dry', 'Wet', 'Potholes', 'Under Construction', 'Sandy'];
const VEHICLE_CATEGORIES = ['Two-Wheeler', 'Car', 'Truck', 'Bus', 'Auto-Rickshaw'];
const TIMEOFDAY_CATEGORIES = ['Morning', 'Afternoon', 'Evening', 'Night'];
const TRAFFIC_CATEGORIES = ['Low', 'Medium', 'High'];

// Feature encoding helper
function encodeFeatures(input: PredictionInput, locationRisk: 'Low' | 'Medium' | 'High'): number[] {
  // One-hot encoding of categorical features
  const encoding: number[] = [];

  // 1. Weather
  WEATHER_CATEGORIES.forEach(cat => encoding.push(input.weatherCondition === cat ? 1 : 0));
  // 2. Road Condition
  ROAD_CATEGORIES.forEach(cat => encoding.push(input.roadCondition === cat ? 1 : 0));
  // 3. Vehicle Type
  VEHICLE_CATEGORIES.forEach(cat => encoding.push(input.vehicleType === cat ? 1 : 0));
  // 4. Time of Day
  TIMEOFDAY_CATEGORIES.forEach(cat => encoding.push(input.timeOfDay === cat ? 1 : 0));
  // 5. Traffic Density
  TRAFFIC_CATEGORIES.forEach(cat => encoding.push(input.trafficDensity === cat ? 1 : 0));
  // 6. Location Risk
  TRAFFIC_CATEGORIES.forEach(cat => encoding.push(locationRisk === cat ? 1 : 0));

  return encoding;
}

const FEATURE_COUNT =
  WEATHER_CATEGORIES.length +
  ROAD_CATEGORIES.length +
  VEHICLE_CATEGORIES.length +
  TIMEOFDAY_CATEGORIES.length +
  TRAFFIC_CATEGORIES.length +
  TRAFFIC_CATEGORIES.length; // location risks

interface MLTrainingSample {
  features: number[];
  label: 'Low' | 'Medium' | 'High';
}

// Evaluate location historical risk level
export function getHistoricalLocationRisk(location: string, records: AccidentRecord[]): 'Low' | 'Medium' | 'High' {
  const locLower = location.toLowerCase();
  const matched = records.filter(r => r.location.toLowerCase().includes(locLower));
  if (matched.length === 0) return 'Medium'; // default to Medium risk for unknown locations
  
  // Calculate risk based on average casualties & fatal ratios
  const total = matched.length;
  const fatalCount = matched.filter(r => r.severityLevel === 'Fatal').length;
  const avgCasualties = matched.reduce((sum, r) => sum + r.numberOfCasualties, 0) / total;

  if (fatalCount / total > 0.3 || avgCasualties > 2.0 || total > 15) {
    return 'High';
  } else if (fatalCount / total > 0.1 || avgCasualties > 1.0 || total > 5) {
    return 'Medium';
  }
  return 'Low';
}

// Prep data for model training
function prepareTrainingData(records: AccidentRecord[]): MLTrainingSample[] {
  return records.map(r => {
    const timeOfDay = getTimeOfDay(r.time);
    const trafficDensity = r.trafficDensity || (r.severityLevel === 'Fatal' ? 'High' : (r.severityLevel === 'Severe' ? 'Medium' : 'Low'));
    const input: PredictionInput = {
      location: r.location,
      weatherCondition: r.weatherCondition,
      timeOfDay,
      roadCondition: r.roadCondition,
      trafficDensity,
      vehicleType: r.vehicleType
    };
    const locationRisk = getHistoricalLocationRisk(r.location, records);
    return {
      features: encodeFeatures(input, locationRisk),
      label: severityToRisk(r.severityLevel)
    };
  });
}

// ----------------- DECISION TREE CLASSIFIER -----------------
interface TreeNode {
  isLeaf: boolean;
  featureIndex?: number;
  predictionDistribution?: { Low: number; Medium: number; High: number };
  left?: TreeNode;
  right?: TreeNode;
}

export class DecisionTree {
  private root: TreeNode | null = null;

  public train(records: AccidentRecord[]) {
    const data = prepareTrainingData(records);
    this.root = this.buildTree(data, 0, 5); // max depth 5
  }

  private buildTree(data: MLTrainingSample[], depth: number, maxDepth: number): TreeNode {
    // Check base cases
    if (data.length === 0) {
      return { isLeaf: true, predictionDistribution: { Low: 0.33, Medium: 0.34, High: 0.33 } };
    }

    const counts = { Low: 0, Medium: 0, High: 0 };
    data.forEach(d => counts[d.label]++);
    
    const total = data.length;
    const distribution = {
      Low: total > 0 ? counts.Low / total : 0.33,
      Medium: total > 0 ? counts.Medium / total : 0.34,
      High: total > 0 ? counts.High / total : 0.33
    };

    // If all same label or reached max depth
    const isPure = counts.Low === total || counts.Medium === total || counts.High === total;
    if (isPure || depth >= maxDepth || total < 3) {
      return { isLeaf: true, predictionDistribution: distribution };
    }

    // Find best feature split (max Gini impurity decrease)
    let bestFeature = -1;
    let bestGiniGain = -1;
    let bestLeftData: MLTrainingSample[] = [];
    let bestRightData: MLTrainingSample[] = [];

    const currentGini = this.calculateGini(data);

    // Scan all features
    for (let f = 0; f < FEATURE_COUNT; f++) {
      const left = data.filter(d => d.features[f] === 1);
      const right = data.filter(d => d.features[f] === 0);

      if (left.length === 0 || right.length === 0) continue;

      const giniLeft = this.calculateGini(left);
      const giniRight = this.calculateGini(right);
      const weightedGini = (left.length / total) * giniLeft + (right.length / total) * giniRight;
      const gain = currentGini - weightedGini;

      if (gain > bestGiniGain) {
        bestGiniGain = gain;
        bestFeature = f;
        bestLeftData = left;
        bestRightData = right;
      }
    }

    if (bestFeature === -1 || bestGiniGain <= 0.01) {
      return { isLeaf: true, predictionDistribution: distribution };
    }

    return {
      isLeaf: false,
      featureIndex: bestFeature,
      left: this.buildTree(bestLeftData, depth + 1, maxDepth),
      right: this.buildTree(bestRightData, depth + 1, maxDepth)
    };
  }

  private calculateGini(data: MLTrainingSample[]): number {
    const total = data.length;
    if (total === 0) return 0;
    const counts = { Low: 0, Medium: 0, High: 0 };
    data.forEach(d => counts[d.label]++);
    const pLow = counts.Low / total;
    const pMedium = counts.Medium / total;
    const pHigh = counts.High / total;
    return 1 - (pLow * pLow + pMedium * pMedium + pHigh * pHigh);
  }

  public predict(input: PredictionInput, locationRisk: 'Low' | 'Medium' | 'High'): { Low: number; Medium: number; High: number } {
    if (!this.root) return { Low: 0.33, Medium: 0.34, High: 0.33 };
    const features = encodeFeatures(input, locationRisk);
    return this.traverseTree(this.root, features);
  }

  private traverseTree(node: TreeNode, features: number[]): { Low: number; Medium: number; High: number } {
    if (node.isLeaf) {
      return node.predictionDistribution || { Low: 0.33, Medium: 0.34, High: 0.33 };
    }
    const fVal = features[node.featureIndex!];
    if (fVal === 1) {
      return this.traverseTree(node.left!, features);
    } else {
      return this.traverseTree(node.right!, features);
    }
  }
}

// ----------------- RANDOM FOREST CLASSIFIER -----------------
export class RandomForest {
  private trees: DecisionTree[] = [];
  private readonly numTrees = 5;

  public train(records: AccidentRecord[]) {
    const data = prepareTrainingData(records);
    this.trees = [];

    for (let i = 0; i < this.numTrees; i++) {
      // Bootstrap aggregate (bagging) - sample with replacement
      const bootstrappedRecords: AccidentRecord[] = [];
      for (let j = 0; j < records.length; j++) {
        const randIndex = Math.floor(Math.random() * records.length);
        bootstrappedRecords.push(records[randIndex]);
      }

      const tree = new DecisionTree();
      tree.train(bootstrappedRecords);
      this.trees.push(tree);
    }
  }

  public predict(input: PredictionInput, locationRisk: 'Low' | 'Medium' | 'High'): { Low: number; Medium: number; High: number } {
    if (this.trees.length === 0) return { Low: 0.33, Medium: 0.34, High: 0.33 };

    const sum = { Low: 0, Medium: 0, High: 0 };
    this.trees.forEach(tree => {
      const p = tree.predict(input, locationRisk);
      sum.Low += p.Low;
      sum.Medium += p.Medium;
      sum.High += p.High;
    });

    const total = this.trees.length;
    return {
      Low: Math.round((sum.Low / total) * 100) / 100,
      Medium: Math.round((sum.Medium / total) * 100) / 100,
      High: Math.round((sum.High / total) * 100) / 100
    };
  }
}

// ----------------- LOGISTIC REGRESSION -----------------
export class LogisticRegression {
  private weights: number[][] = []; // [3 classes] [FEATURE_COUNT]
  private bias: number[] = [0, 0, 0]; // [3 classes]

  public train(records: AccidentRecord[]) {
    const data = prepareTrainingData(records);
    const classes: ('Low' | 'Medium' | 'High')[] = ['Low', 'Medium', 'High'];
    
    // Initialize weights and biases
    this.weights = [
      new Array(FEATURE_COUNT).fill(0).map(() => (Math.random() - 0.5) * 0.1),
      new Array(FEATURE_COUNT).fill(0).map(() => (Math.random() - 0.5) * 0.1),
      new Array(FEATURE_COUNT).fill(0).map(() => (Math.random() - 0.5) * 0.1)
    ];
    this.bias = [0, 0, 0];

    if (data.length === 0) return;

    // Gradient descent
    const epochs = 100;
    const lr = 0.05;

    for (let epoch = 0; epoch < epochs; epoch++) {
      data.forEach(sample => {
        const x = sample.features;
        // One-hot encode label
        const y = [
          sample.label === 'Low' ? 1 : 0,
          sample.label === 'Medium' ? 1 : 0,
          sample.label === 'High' ? 1 : 0
        ];

        // Forward pass: Calculate logits (scores)
        const scores = [0, 0, 0];
        for (let c = 0; c < 3; c++) {
          let score = this.bias[c];
          for (let f = 0; f < FEATURE_COUNT; f++) {
            score += this.weights[c][f] * x[f];
          }
          scores[c] = score;
        }

        // Softmax
        const maxScore = Math.max(...scores); // for numerical stability
        const expScores = scores.map(s => Math.exp(s - maxScore));
        const sumExp = expScores.reduce((sum, e) => sum + e, 0);
        const probabilities = expScores.map(e => e / sumExp);

        // Backward pass: Update weights & bias (gradient of cross-entropy loss)
        for (let c = 0; c < 3; c++) {
          const error = probabilities[c] - y[c];
          this.bias[c] -= lr * error;
          for (let f = 0; f < FEATURE_COUNT; f++) {
            this.weights[c][f] -= lr * error * x[f];
          }
        }
      });
    }
  }

  public predict(input: PredictionInput, locationRisk: 'Low' | 'Medium' | 'High'): { Low: number; Medium: number; High: number } {
    if (this.weights.length === 0) return { Low: 0.33, Medium: 0.34, High: 0.33 };

    const x = encodeFeatures(input, locationRisk);
    const scores = [0, 0, 0];

    for (let c = 0; c < 3; c++) {
      let score = this.bias[c];
      for (let f = 0; f < FEATURE_COUNT; f++) {
        score += this.weights[c][f] * x[f];
      }
      scores[c] = score;
    }

    const maxScore = Math.max(...scores);
    const expScores = scores.map(s => Math.exp(s - maxScore));
    const sumExp = expScores.reduce((sum, e) => sum + e, 0);

    const Low = expScores[0] / sumExp;
    const Medium = expScores[1] / sumExp;
    const High = expScores[2] / sumExp;

    return {
      Low: Math.round(Low * 100) / 100,
      Medium: Math.round(Medium * 100) / 100,
      High: Math.round(High * 100) / 100
    };
  }
}

// Global trained models singleton references
let dtModel: DecisionTree | null = null;
let rfModel: RandomForest | null = null;
let lrModel: LogisticRegression | null = null;

export function predictAccidentRisk(
  input: PredictionInput,
  records: AccidentRecord[],
  algorithm: 'Decision Tree' | 'Random Forest' | 'Logistic Regression'
): PredictionResult {
  // Lazily train models if not trained yet
  if (!dtModel || !rfModel || !lrModel) {
    dtModel = new DecisionTree();
    dtModel.train(records);

    rfModel = new RandomForest();
    rfModel.train(records);

    lrModel = new LogisticRegression();
    lrModel.train(records);
  }

  const locationRisk = getHistoricalLocationRisk(input.location, records);

  let probabilities = { Low: 0.33, Medium: 0.34, High: 0.33 };

  if (algorithm === 'Decision Tree') {
    probabilities = dtModel.predict(input, locationRisk);
  } else if (algorithm === 'Random Forest') {
    probabilities = rfModel.predict(input, locationRisk);
  } else if (algorithm === 'Logistic Regression') {
    probabilities = lrModel.predict(input, locationRisk);
  }

  // Determine highest predicted risk
  let predictedRisk: 'Low' | 'Medium' | 'High' = 'Medium';
  if (probabilities.Low >= probabilities.Medium && probabilities.Low >= probabilities.High) {
    predictedRisk = 'Low';
  } else if (probabilities.Medium >= probabilities.Low && probabilities.Medium >= probabilities.High) {
    predictedRisk = 'Medium';
  } else {
    predictedRisk = 'High';
  }

  return {
    algorithm,
    predictedRisk,
    probabilities
  };
}

// Force retrain of models (e.g. after database upload)
export function retrainMLModels(records: AccidentRecord[]) {
  dtModel = new DecisionTree();
  dtModel.train(records);

  rfModel = new RandomForest();
  rfModel.train(records);

  lrModel = new LogisticRegression();
  lrModel.train(records);
}
