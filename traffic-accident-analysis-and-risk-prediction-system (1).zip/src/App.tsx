import { useState, useEffect, FormEvent } from 'react';
import { 
  AlertTriangle, 
  Upload, 
  MapPin, 
  ShieldCheck, 
  FileText, 
  Brain, 
  Compass, 
  TrendingUp, 
  Plus, 
  RefreshCw, 
  Database, 
  Lock, 
  Unlock, 
  LogOut, 
  User, 
  Layers, 
  Sparkles, 
  ChevronRight,
  Filter, 
  Search, 
  Calendar,
  X,
  Map as MapIcon,
  ChevronDown
} from 'lucide-react';
import { 
  AreaChart, 
  Area, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer, 
  BarChart, 
  Bar, 
  Cell, 
  PieChart, 
  Pie, 
  Legend 
} from 'recharts';

import { AccidentRecord, DashboardStats, PredictionInput, PredictionResult, RouteRecommendationResult } from './types';
import { Hotspot } from './db';
import AccidentMap from './components/AccidentMap';

export default function App() {
  // Authentication State
  const [isAdmin, setIsAdmin] = useState<boolean>(() => {
    return localStorage.getItem('smartcity_admin_auth') === 'true';
  });
  const [username, setUsername] = useState('');
  const [password, setPassword] = useState('');
  const [authError, setAuthError] = useState('');
  const [showLoginModal, setShowLoginModal] = useState(false);

  // Core App States
  const [currentTab, setCurrentTab] = useState<'dashboard' | 'analysis' | 'predict' | 'hotspots' | 'routes' | 'reports'>('dashboard');
  const [accidents, setAccidents] = useState<AccidentRecord[]>([]);
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [hotspots, setHotspots] = useState<Hotspot[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [apiError, setApiError] = useState<string>('');

  // Dashboard / Analysis Filters
  const [selectedCity, setSelectedCity] = useState<string>('All');
  const [severityFilter, setSeverityFilter] = useState<string>('All');
  const [causeFilter, setCauseFilter] = useState<string>('All');
  const [searchKeyword, setSearchKeyword] = useState<string>('');

  // ML Risk Prediction States
  const [predictLocation, setPredictLocation] = useState('Western Express Highway, Mumbai');
  const [predictWeather, setPredictWeather] = useState('Clear');
  const [predictRoad, setPredictRoad] = useState('Dry');
  const [predictVehicle, setPredictVehicle] = useState('Car');
  const [predictTime, setPredictTime] = useState<'Morning' | 'Afternoon' | 'Evening' | 'Night'>('Evening');
  const [predictTraffic, setPredictTraffic] = useState<'Low' | 'Medium' | 'High'>('High');
  const [predictAlgo, setPredictAlgo] = useState<'Decision Tree' | 'Random Forest' | 'Logistic Regression'>('Random Forest');
  const [predictionResult, setPredictionResult] = useState<PredictionResult | null>(null);
  const [predicting, setPredicting] = useState(false);

  // Safe Route States
  const [routeSource, setRouteSource] = useState('Sion Circle, Mumbai');
  const [routeDest, setRouteDest] = useState('Saki Naka, Mumbai');
  const [routingResult, setRoutingResult] = useState<RouteRecommendationResult | null>(null);
  const [calculatingRoute, setCalculatingRoute] = useState(false);

  // CSV Upload States
  const [csvContent, setCsvContent] = useState('');
  const [uploadSuccess, setUploadSuccess] = useState('');
  const [uploadErrors, setUploadErrors] = useState<string[]>([]);
  const [showUploadModal, setShowUploadModal] = useState(false);

  // Manual Entry State
  const [showAddModal, setShowAddModal] = useState(false);
  const [newRecord, setNewRecord] = useState<Partial<AccidentRecord>>({
    date: new Date().toISOString().split('T')[0],
    time: '18:30',
    location: '',
    latitude: 19.0760,
    longitude: 72.8777,
    weatherCondition: 'Clear',
    roadCondition: 'Dry',
    vehicleType: 'Car',
    accidentCause: 'Overspeeding',
    severityLevel: 'Severe',
    numberOfCasualties: 1,
  });

  // AI Insights State
  const [aiInsights, setAiInsights] = useState<string>('');
  const [loadingAI, setLoadingAI] = useState<boolean>(false);

  // Hotspots Highlight State
  const [activeHotspotId, setActiveHotspotId] = useState<string | undefined>(undefined);

  // Load Initial Database Data
  const fetchDatabase = async () => {
    setLoading(true);
    setApiError('');
    try {
      const response = await fetch('/api/accidents');
      const data = await response.json();
      if (data.success) {
        setAccidents(data.records);
        setStats(data.stats);
        setHotspots(data.hotspots);
      } else {
        setApiError(data.message || 'Failed to fetch database records.');
      }
    } catch (err: any) {
      setApiError(err.message || 'Error connecting to the backend server.');
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    fetchDatabase();
  }, []);

  // Filter accidents dynamically for front-end charts/stats based on selectedCity
  const filteredAccidents = accidents.filter(r => {
    const cityMatch = selectedCity === 'All' || r.location.toLowerCase().includes(selectedCity.toLowerCase());
    const severityMatch = severityFilter === 'All' || r.severityLevel === severityFilter;
    const causeMatch = causeFilter === 'All' || r.accidentCause === causeFilter;
    const keywordMatch = searchKeyword === '' || 
      r.location.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      r.accidentId.toLowerCase().includes(searchKeyword.toLowerCase()) ||
      r.accidentCause.toLowerCase().includes(searchKeyword.toLowerCase());
    return cityMatch && severityMatch && causeMatch && keywordMatch;
  });

  // Re-calculate statistics for filtered lists in frontend
  const getFilteredStats = () => {
    if (filteredAccidents.length === 0) return null;
    
    const total = filteredAccidents.length;
    const fatal = filteredAccidents.filter(r => r.severityLevel === 'Fatal').length;
    const severe = filteredAccidents.filter(r => r.severityLevel === 'Severe').length;
    const minor = filteredAccidents.filter(r => r.severityLevel === 'Minor').length;
    const casualties = filteredAccidents.reduce((sum, r) => sum + r.numberOfCasualties, 0);

    const severityData = [
      { name: 'Fatal', value: fatal, color: '#f43f5e' },
      { name: 'Severe Injury', value: severe, color: '#f59e0b' },
      { name: 'Minor / Property', value: minor, color: '#eab308' },
    ].filter(d => d.value > 0);

    // Cause stats
    const causeCounts: Record<string, number> = {};
    filteredAccidents.forEach(r => {
      causeCounts[r.accidentCause] = (causeCounts[r.accidentCause] || 0) + 1;
    });
    const causeData = Object.entries(causeCounts).map(([name, value]) => ({ name, value })).sort((a,b) => b.value - a.value);

    // Vehicle stats
    const vehicleCounts: Record<string, number> = {};
    filteredAccidents.forEach(r => {
      vehicleCounts[r.vehicleType] = (vehicleCounts[r.vehicleType] || 0) + 1;
    });
    const vehicleData = Object.entries(vehicleCounts).map(([name, value]) => ({ name, value }));

    // Monthly trends
    const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
    const monthCounts: Record<string, number> = {};
    monthNames.forEach(m => { monthCounts[m] = 0; });
    filteredAccidents.forEach(r => {
      if (!r.date) return;
      const mIdx = parseInt(r.date.split('-')[1], 10) - 1;
      if (mIdx >= 0 && mIdx < 12) {
        monthCounts[monthNames[mIdx]]++;
      }
    });
    const monthlyTrendData = monthNames.map(name => ({ name, count: monthCounts[name] }));

    return {
      total,
      fatal,
      severe,
      minor,
      casualties,
      severityData,
      causeData,
      vehicleData,
      monthlyTrendData
    };
  };

  const fStats = getFilteredStats();

  // Admin Login Handler
  const handleLogin = async (e: FormEvent) => {
    e.preventDefault();
    setAuthError('');
    try {
      const response = await fetch('/api/auth/login', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ username, password })
      });
      const data = await response.json();
      if (data.success) {
        setIsAdmin(true);
        localStorage.setItem('smartcity_admin_auth', 'true');
        setShowLoginModal(false);
        setUsername('');
        setPassword('');
      } else {
        setAuthError(data.message || 'Failed to authenticate.');
      }
    } catch (err) {
      setAuthError('Connection error to auth API.');
    }
  };

  // Log out Admin
  const handleLogout = () => {
    setIsAdmin(false);
    localStorage.removeItem('smartcity_admin_auth');
  };

  // Database Reset Handler
  const handleResetDatabase = async () => {
    if (!isAdmin) {
      setShowLoginModal(true);
      return;
    }

    if (confirm('Are you sure you want to reset the entire database to the default seed Indian accident records?')) {
      setLoading(true);
      try {
        const response = await fetch('/api/accidents/reset', { method: 'POST' });
        const data = await response.json();
        if (data.success) {
          setAccidents(data.records);
          setStats(data.stats);
          setHotspots(data.hotspots);
          setAiInsights('');
          setPredictionResult(null);
          setRoutingResult(null);
          alert('Database reset successfully.');
        }
      } catch (err) {
        alert('Reset failed.');
      } finally {
        setLoading(false);
      }
    }
  };

  // CSV Bulk Upload Handler
  const handleCSVUpload = async () => {
    if (!csvContent.trim()) {
      alert('Please paste some CSV data first.');
      return;
    }
    setLoading(true);
    setUploadErrors([]);
    setUploadSuccess('');
    try {
      const response = await fetch('/api/accidents/upload', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ csvContent })
      });
      const data = await response.json();
      if (data.success) {
        setUploadSuccess(data.message);
        setAccidents(data.records);
        setStats(data.stats);
        setHotspots(data.hotspots);
        if (data.errors && data.errors.length > 0) {
          setUploadErrors(data.errors);
        }
        setCsvContent('');
        setTimeout(() => {
          setShowUploadModal(false);
          setUploadSuccess('');
        }, 2000);
      } else {
        setUploadErrors([data.message || 'Bulk upload failed.']);
      }
    } catch (err: any) {
      setUploadErrors([err.message || 'Error uploading CSV.']);
    } finally {
      setLoading(false);
    }
  };

  // Handle Manual Accident Creation
  const handleAddRecord = async (e: FormEvent) => {
    e.preventDefault();
    try {
      const randId = `MAN-${Math.floor(1000 + Math.random() * 9000)}`;
      const payload = {
        ...newRecord,
        accidentId: randId,
        latitude: Number(newRecord.latitude),
        longitude: Number(newRecord.longitude),
        numberOfCasualties: Number(newRecord.numberOfCasualties),
        trafficDensity: newRecord.severityLevel === 'Fatal' ? 'High' : (newRecord.severityLevel === 'Severe' ? 'Medium' : 'Low')
      };

      const response = await fetch('/api/accidents/add', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });
      const data = await response.json();
      if (data.success) {
        setAccidents(data.records);
        setStats(data.stats);
        setHotspots(data.hotspots);
        setShowAddModal(false);
        alert(`Successfully added new accident record with ID ${randId}`);
      }
    } catch (err) {
      alert('Failed to insert record.');
    }
  };

  // ML Predict Handler
  const handlePredictRisk = async (e: FormEvent) => {
    e.preventDefault();
    setPredicting(true);
    try {
      const response = await fetch('/api/predict', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          location: predictLocation,
          weatherCondition: predictWeather,
          timeOfDay: predictTime,
          roadCondition: predictRoad,
          trafficDensity: predictTraffic,
          vehicleType: predictVehicle,
          algorithm: predictAlgo
        })
      });
      const data = await response.json();
      if (data.success) {
        setPredictionResult(data.result);
      } else {
        alert(data.message || 'Risk prediction failed.');
      }
    } catch (err: any) {
      alert('Error predicting: ' + err.message);
    } finally {
      setPredicting(false);
    }
  };

  // Safe Route Advisor Handler
  const handleCalculateRoutes = async (e: FormEvent) => {
    e.preventDefault();
    setCalculatingRoute(true);
    try {
      const response = await fetch('/api/routes', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          source: routeSource,
          destination: routeDest
        })
      });
      const data = await response.json();
      if (data.success) {
        setRoutingResult(data.result);
      } else {
        alert(data.message || 'Route planning failed.');
      }
    } catch (err: any) {
      alert('Error: ' + err.message);
    } finally {
      setCalculatingRoute(false);
    }
  };

  // Request AI Traffic Safety Insights
  const handleGenerateAIInsights = async () => {
    setLoadingAI(true);
    setAiInsights('');
    try {
      const response = await fetch('/api/ai-insights', { method: 'POST' });
      const data = await response.json();
      if (data.success) {
        setAiInsights(data.insights);
      } else {
        setAiInsights('Error triggering AI Analyst: ' + data.message);
      }
    } catch (err: any) {
      setAiInsights('Network error compiling AI insights.');
    } finally {
      setLoadingAI(false);
    }
  };

  // Sample CSV format generator
  const loadCSVSample = () => {
    const sample = `Accident ID,Date,Time,Location,Latitude,Longitude,Weather condition,Road condition,Vehicle type,Accident cause,Severity level,Number of casualties
IND-MUM-401,2026-05-12,21:40,"Western Express Highway, Mumbai",19.1156,72.8560,Rain,Wet,Car,Overspeeding,Severe,2
IND-DEL-402,2026-05-13,23:10,"Dhaula Kuan Chowk, Delhi",28.5918,77.1612,Fog,Dry,Truck,Drunk Driving,Fatal,1
IND-BLR-403,2026-05-14,08:15,"Silk Board Junction, Bangalore",12.9176,77.6244,Clear,Dry,Two-Wheeler,Traffic Violation,Minor,0`;
    setCsvContent(sample);
  };

  return (
    <div className="min-h-screen bg-slate-950 text-slate-100 font-sans flex flex-col selection:bg-indigo-500 selection:text-white">
      
      {/* Smart City Header */}
      <header className="no-print border-b border-slate-900 bg-slate-950/80 backdrop-blur-md sticky top-0 z-40 px-4 md:px-8 py-4 flex flex-col md:flex-row md:items-center md:justify-between gap-4">
        <div className="flex items-center gap-3">
          <div className="h-10 w-10 rounded-lg bg-indigo-600 flex items-center justify-center shadow-lg shadow-indigo-500/20 ring-1 ring-indigo-400/30">
            <AlertTriangle className="h-5 w-5 text-indigo-200 animate-pulse" />
          </div>
          <div>
            <h1 className="text-lg md:text-xl font-bold tracking-tight text-white font-display flex items-center gap-2">
              TRAFFIC SAFETY SENTRY
              <span className="text-[9px] bg-emerald-500/10 text-emerald-400 font-mono px-1.5 py-0.5 rounded border border-emerald-500/20">LIVE-ANALYTICS</span>
            </h1>
            <p className="text-xs text-slate-400">Accident Analysis & Risk Prediction Intelligence Core</p>
          </div>
        </div>

        {/* Global Controls */}
        <div className="flex flex-wrap items-center gap-2.5">
          {/* City Filter Dropdown */}
          <div className="flex items-center gap-1.5 bg-slate-900 border border-slate-800 rounded-lg px-2.5 py-1.5 text-xs text-slate-300">
            <Filter className="h-3 w-3 text-indigo-400" />
            <span className="font-medium">Scope:</span>
            <select 
              value={selectedCity} 
              onChange={(e) => setSelectedCity(e.target.value)}
              className="bg-transparent border-none text-white focus:outline-none cursor-pointer pr-4 font-semibold"
            >
              <option value="All" className="bg-slate-900">All Indian Metros</option>
              <option value="Mumbai" className="bg-slate-900">Mumbai Metro</option>
              <option value="Bangalore" className="bg-slate-900">Bangalore Metro</option>
              <option value="Delhi" className="bg-slate-900">Delhi Metro</option>
              <option value="Hyderabad" className="bg-slate-900">Hyderabad Metro</option>
              <option value="Pune" className="bg-slate-900">Pune Metro</option>
              <option value="Chennai" className="bg-slate-900">Chennai Metro</option>
              <option value="Kolkata" className="bg-slate-900">Kolkata Metro</option>
              <option value="Jaipur" className="bg-slate-900">Jaipur Region</option>
              <option value="Lucknow" className="bg-slate-900">Lucknow Metro</option>
              <option value="Ahmedabad" className="bg-slate-900">Ahmedabad Metro</option>
              <option value="Guwahati" className="bg-slate-900">Guwahati Metro</option>
              <option value="Kochi" className="bg-slate-900">Kochi Metro</option>
              <option value="Bhopal" className="bg-slate-900">Bhopal Metro</option>
              <option value="Srinagar" className="bg-slate-900">Srinagar Region</option>
              <option value="Chandigarh" className="bg-slate-900">Chandigarh Metro</option>
              <option value="Patna" className="bg-slate-900">Patna Metro</option>
              <option value="Bhubaneswar" className="bg-slate-900">Bhubaneswar Metro</option>
              <option value="Nagpur" className="bg-slate-900">Nagpur Metro</option>
              <option value="Goa" className="bg-slate-900">Goa Region</option>
            </select>
          </div>

          {/* Seed/Reset DB Button */}
          <button 
            onClick={handleResetDatabase}
            className="flex items-center gap-1.5 text-xs font-medium text-slate-300 bg-slate-900 hover:bg-slate-800 border border-slate-800 hover:border-slate-700 px-3 py-1.5 rounded-lg transition-colors cursor-pointer"
            title="Reset to default seed data"
          >
            <Database className="h-3.5 w-3.5 text-indigo-400" />
            Reset Data
          </button>

          {/* Admin auth controls */}
          {isAdmin ? (
            <div className="flex items-center gap-2">
              <span className="text-xs text-emerald-400 font-mono bg-emerald-500/10 px-2 py-1 rounded border border-emerald-500/20 flex items-center gap-1">
                <Unlock className="h-3 w-3" /> Admin Mode
              </span>
              <button 
                onClick={handleLogout}
                className="flex items-center gap-1 text-xs font-semibold text-slate-300 hover:text-white bg-rose-950/20 hover:bg-rose-950/40 border border-rose-900/30 px-3 py-1.5 rounded-lg transition-all cursor-pointer"
              >
                <LogOut className="h-3.5 w-3.5 text-rose-400" />
                Sign Out
              </button>
            </div>
          ) : (
            <button 
              onClick={() => setShowLoginModal(true)}
              className="flex items-center gap-1.5 text-xs font-semibold text-indigo-300 hover:text-white bg-indigo-950/20 hover:bg-indigo-950/40 border border-indigo-900/30 px-3 py-1.5 rounded-lg transition-all cursor-pointer"
            >
              <Lock className="h-3.5 w-3.5 text-indigo-400" />
              Admin Portal
            </button>
          )}
        </div>
      </header>

      {/* Main Container Grid */}
      <div className="flex-1 max-w-7xl w-full mx-auto p-4 md:p-6 lg:p-8 flex flex-col gap-6">
        
        {/* Navigation Tabs */}
        <nav className="no-print flex flex-wrap border-b border-slate-900 bg-slate-950/40 p-1.5 rounded-xl gap-1">
          {[
            { id: 'dashboard', label: 'Dashboard', icon: TrendingUp },
            { id: 'analysis', label: 'Safety Factors', icon: Sparkles },
            { id: 'hotspots', label: 'Hotspot Detector', icon: Layers },
            { id: 'predict', label: 'AI Risk Predictor', icon: Brain },
            { id: 'routes', label: 'Safe Route Advisor', icon: Compass },
            { id: 'reports', label: 'Dossiers & PDF Export', icon: FileText },
          ].map((tab) => {
            const Icon = tab.icon;
            const active = currentTab === tab.id;
            return (
              <button
                key={tab.id}
                onClick={() => setCurrentTab(tab.id as any)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-lg text-xs font-semibold tracking-wide transition-all cursor-pointer ${
                  active 
                    ? 'bg-indigo-600/10 text-indigo-400 border border-indigo-500/20 shadow-md' 
                    : 'text-slate-400 hover:text-slate-200 hover:bg-slate-900/50'
                }`}
              >
                <Icon className={`h-4 w-4 ${active ? 'text-indigo-400' : 'text-slate-400'}`} />
                {tab.label}
              </button>
            );
          })}
        </nav>

        {/* Global Loading / Error Notifications */}
        {loading && (
          <div className="no-print bg-slate-900/50 border border-slate-800 p-4 rounded-xl flex items-center justify-center gap-3">
            <RefreshCw className="h-5 w-5 text-indigo-500 animate-spin" />
            <span className="text-xs font-semibold text-slate-300 font-mono">Synchronizing central database registries...</span>
          </div>
        )}
        {apiError && (
          <div className="bg-rose-500/10 border border-rose-500/20 text-rose-400 p-4 rounded-xl text-xs flex items-center gap-2">
            <AlertTriangle className="h-4 w-4 shrink-0" />
            <span>{apiError}</span>
          </div>
        )}

        {/* ==================== TAB 1: INTERACTIVE DASHBOARD ==================== */}
        {currentTab === 'dashboard' && stats && (
          <div className="flex flex-col gap-6 animate-fade-in">
            {/* Action panel */}
            <div className="no-print flex flex-col md:flex-row items-center justify-between bg-slate-900/35 border border-slate-900 p-4 rounded-xl gap-4">
              <div className="text-xs">
                <span className="text-slate-400">Scoped Metro Filter: </span>
                <span className="font-semibold text-indigo-400 text-sm font-display">{selectedCity === 'All' ? 'All Metros' : `${selectedCity} City`}</span>
                <span className="text-slate-400"> ({filteredAccidents.length} incidents matching)</span>
              </div>
              <div className="flex flex-wrap items-center gap-2">
                <button 
                  onClick={() => {
                    if (isAdmin) setShowAddModal(true);
                    else {
                      alert('Administrative authorization required to register manual logs.');
                      setShowLoginModal(true);
                    }
                  }}
                  className="flex items-center gap-1.5 text-xs font-bold text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 border border-emerald-500/20 px-3.5 py-2 rounded-lg transition-all cursor-pointer"
                >
                  <Plus className="h-3.5 w-3.5" /> Log Incident
                </button>
                <button 
                  onClick={() => {
                    if (isAdmin) setShowUploadModal(true);
                    else {
                      alert('Administrative authorization required to access CSV bulk registers.');
                      setShowLoginModal(true);
                    }
                  }}
                  className="flex items-center gap-1.5 text-xs font-bold text-indigo-300 bg-indigo-600/10 hover:bg-indigo-600/20 border border-indigo-500/20 px-3.5 py-2 rounded-lg transition-all cursor-pointer"
                >
                  <Upload className="h-3.5 w-3.5" /> Bulk CSV Upload
                </button>
              </div>
            </div>

            {/* KPI STATS Grid */}
            <div className="grid grid-cols-2 lg:grid-cols-5 gap-4">
              <div className="bg-slate-900 border border-slate-900 rounded-xl p-4 flex flex-col">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Total Accidents</span>
                <span className="text-2xl md:text-3xl font-extrabold text-white mt-1.5 font-display">
                  {fStats ? fStats.total : 0}
                </span>
                <span className="text-[10px] text-slate-500 mt-1">Recorded incidents</span>
              </div>
              
              <div className="bg-rose-950/20 border border-rose-900/20 rounded-xl p-4 flex flex-col">
                <span className="text-xs font-semibold text-rose-400 uppercase tracking-wider flex items-center gap-1">
                  <span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span> Fatalities
                </span>
                <span className="text-2xl md:text-3xl font-extrabold text-rose-400 mt-1.5 font-display">
                  {fStats ? fStats.fatal : 0}
                </span>
                <span className="text-[10px] text-rose-500 mt-1">Immediate fatal reports</span>
              </div>

              <div className="bg-amber-950/20 border border-amber-900/20 rounded-xl p-4 flex flex-col">
                <span className="text-xs font-semibold text-amber-400 uppercase tracking-wider">Severe Injuries</span>
                <span className="text-2xl md:text-3xl font-extrabold text-amber-500 mt-1.5 font-display">
                  {fStats ? fStats.severe : 0}
                </span>
                <span className="text-[10px] text-amber-500 mt-1">Major trauma incidents</span>
              </div>

              <div className="bg-slate-900 border border-slate-900 rounded-xl p-4 flex flex-col">
                <span className="text-xs font-semibold text-slate-400 uppercase tracking-wider">Minor Damage</span>
                <span className="text-2xl md:text-3xl font-extrabold text-slate-300 mt-1.5 font-display">
                  {fStats ? fStats.minor : 0}
                </span>
                <span className="text-[10px] text-slate-500 mt-1">Property damage logs</span>
              </div>

              <div className="bg-indigo-950/20 border border-indigo-900/20 rounded-xl p-4 flex flex-col col-span-2 lg:col-span-1">
                <span className="text-xs font-semibold text-indigo-400 uppercase tracking-wider">Total Casualties</span>
                <span className="text-2xl md:text-3xl font-extrabold text-indigo-400 mt-1.5 font-display">
                  {fStats ? fStats.casualties : 0}
                </span>
                <span className="text-[10px] text-indigo-500 mt-1">Injured/Deceased count</span>
              </div>
            </div>

            {/* CHARTS ROW 1 */}
            <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
              {/* Monthly Trend Area Chart */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl lg:col-span-2 flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <h3 className="text-sm font-bold text-white tracking-wide uppercase font-display">Accident Trends Over Time</h3>
                  <span className="text-[10px] text-slate-500 font-mono font-medium">Monthly Aggregation (2026)</span>
                </div>
                <div className="h-64 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <AreaChart data={fStats ? fStats.monthlyTrendData : []}>
                      <defs>
                        <linearGradient id="colorCount" x1="0" y1="0" x2="0" y2="1">
                          <stop offset="5%" stopColor="#6366f1" stopOpacity={0.3}/>
                          <stop offset="95%" stopColor="#6366f1" stopOpacity={0}/>
                        </linearGradient>
                      </defs>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={11} />
                      <YAxis stroke="#64748b" fontSize={11} allowDecimals={false} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '12px' }} />
                      <Area type="monotone" dataKey="count" stroke="#6366f1" strokeWidth={2} fillOpacity={1} fill="url(#colorCount)" name="Accidents" />
                    </AreaChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Severity Pie Chart */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <h3 className="text-sm font-bold text-white tracking-wide uppercase font-display">Severity Level Allocation</h3>
                  <span className="text-[10px] text-slate-500 font-mono">Fatality Ratio Analysis</span>
                </div>
                <div className="h-64 w-full flex items-center justify-center relative">
                  {fStats && fStats.total > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <PieChart>
                        <Pie
                          data={fStats.severityData}
                          cx="50%"
                          cy="50%"
                          innerRadius={60}
                          outerRadius={85}
                          paddingAngle={3}
                          dataKey="value"
                        >
                          {fStats.severityData.map((entry: any, index) => (
                            <Cell key={`cell-${index}`} fill={entry.color} />
                          ))}
                        </Pie>
                        <Tooltip formatter={(value) => [`${value} incidents`, 'Severity']} contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '11px' }} />
                        <Legend verticalAlign="bottom" height={36} iconSize={8} iconType="circle" wrapperStyle={{ fontSize: '10px', color: '#94a3b8' }} />
                      </PieChart>
                    </ResponsiveContainer>
                  ) : (
                    <span className="text-xs text-slate-500 font-mono">No data points matching filters</span>
                  )}
                </div>
              </div>
            </div>

            {/* CHARTS ROW 2 & MOST DANGEROUS JUNCTIONS */}
            <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
              {/* Primary Accident Causes Bar Chart */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <h3 className="text-sm font-bold text-white tracking-wide uppercase font-display">Common Accident Causes</h3>
                  <span className="text-[10px] text-slate-500 font-mono">Incident Frequency Rank</span>
                </div>
                <div className="h-64 w-full">
                  {fStats && fStats.causeData.length > 0 ? (
                    <ResponsiveContainer width="100%" height="100%">
                      <BarChart data={fStats.causeData} layout="vertical" margin={{ left: 20 }}>
                        <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" horizontal={false} />
                        <XAxis type="number" stroke="#64748b" fontSize={11} />
                        <YAxis dataKey="name" type="category" stroke="#64748b" fontSize={10} width={110} />
                        <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', color: '#fff', borderRadius: '8px', fontSize: '12px' }} />
                        <Bar dataKey="value" fill="#6366f1" name="Accidents" radius={[0, 4, 4, 0]}>
                          {fStats.causeData.map((entry, index) => (
                            <Cell key={`cell-${index}`} fill={index === 0 ? '#ef4444' : index === 1 ? '#f97316' : '#6366f1'} />
                          ))}
                        </Bar>
                      </BarChart>
                    </ResponsiveContainer>
                  ) : (
                    <div className="h-full flex items-center justify-center text-xs text-slate-500 font-mono">No data matching scope</div>
                  )}
                </div>
              </div>

              {/* Most Dangerous Locations Leaderboard */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <div className="flex items-center justify-between border-b border-slate-900 pb-3">
                  <h3 className="text-sm font-bold text-white tracking-wide uppercase font-display">Highest Risk Road Segments</h3>
                  <span className="text-[10px] text-rose-500 font-mono font-medium">Critical Hotspot Rankings</span>
                </div>
                <div className="flex-1 flex flex-col justify-center gap-3.5">
                  {stats.mostDangerousLocations.map((loc, idx) => (
                    <div key={loc.name} className="flex items-center justify-between p-3.5 bg-slate-950/40 border border-slate-900/80 rounded-xl">
                      <div className="flex items-center gap-3">
                        <span className={`h-6 w-6 rounded-full flex items-center justify-center text-[10px] font-mono font-bold ${
                          idx === 0 ? 'bg-rose-500/10 text-rose-400 border border-rose-500/30' :
                          idx === 1 ? 'bg-amber-500/10 text-amber-400 border border-amber-500/30' :
                          'bg-slate-900 text-slate-400 border border-slate-800'
                        }`}>
                          0{idx + 1}
                        </span>
                        <div>
                          <p className="text-xs font-semibold text-white">{loc.name}</p>
                          <p className="text-[10px] text-rose-400/80 font-medium">{loc.fatalCount} lives lost (fatalities)</p>
                        </div>
                      </div>
                      <div className="text-right">
                        <span className="text-sm font-bold text-slate-200 font-mono">{loc.count}</span>
                        <p className="text-[9px] text-slate-500 font-medium uppercase tracking-wide">Incidents</p>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </div>

            {/* MAP SNAPSHOT CONTAINER */}
            <div className="bg-slate-900/30 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
              <div className="flex flex-col md:flex-row md:items-center justify-between gap-2 border-b border-slate-900 pb-3">
                <div>
                  <h3 className="text-sm font-bold text-white uppercase tracking-wide font-display flex items-center gap-2">
                    <MapIcon className="h-4 w-4 text-indigo-400" /> Geographic Risk Distribution Map
                  </h3>
                  <p className="text-xs text-slate-400 mt-0.5">Real-time mapping clusters compiled from active traffic registries</p>
                </div>
                <button 
                  onClick={() => setCurrentTab('hotspots')}
                  className="text-xs font-bold text-indigo-400 hover:text-indigo-300 flex items-center gap-1 cursor-pointer"
                >
                  Maximize Map View <ChevronRight className="h-3 w-3" />
                </button>
              </div>
              <div className="h-[350px] w-full rounded-xl overflow-hidden">
                <AccidentMap 
                  records={filteredAccidents} 
                  hotspots={hotspots}
                  centerCity={selectedCity !== 'All' ? selectedCity : undefined}
                />
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 2: ACCIDENT FACTOR ANALYSIS (AI INSIGHTS) ==================== */}
        {currentTab === 'analysis' && stats && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
            {/* Factor breakdown charts */}
            <div className="lg:col-span-5 flex flex-col gap-6">
              {/* Vehicle risk factor bar */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wide border-b border-slate-900 pb-3 font-display">Vehicle Involvement Factors</h3>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.vehicleStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: '11px' }} />
                      <Bar dataKey="value" fill="#6366f1" name="Incidents" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Time of Day bar */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wide border-b border-slate-900 pb-3 font-display">Time-of-Day Risk Breakdown</h3>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.timeStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: '11px' }} />
                      <Bar dataKey="value" fill="#f59e0b" name="Incidents" radius={[4, 4, 0, 0]}>
                        {stats.timeStats.map((entry, index) => (
                          <Cell key={`cell-${index}`} fill={entry.name === 'Night' ? '#ec4899' : entry.name === 'Evening' ? '#f43f5e' : '#f59e0b'} />
                        ))}
                      </Bar>
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>

              {/* Weather conditions */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wide border-b border-slate-900 pb-3 font-display">Weather Conditions Distribution</h3>
                <div className="h-56 w-full">
                  <ResponsiveContainer width="100%" height="100%">
                    <BarChart data={stats.weatherStats}>
                      <CartesianGrid strokeDasharray="3 3" stroke="#1e293b" vertical={false} />
                      <XAxis dataKey="name" stroke="#64748b" fontSize={10} />
                      <YAxis stroke="#64748b" fontSize={11} />
                      <Tooltip contentStyle={{ backgroundColor: '#0f172a', borderColor: '#1e293b', fontSize: '11px' }} />
                      <Bar dataKey="value" fill="#3b82f6" name="Incidents" radius={[4, 4, 0, 0]} />
                    </BarChart>
                  </ResponsiveContainer>
                </div>
              </div>
            </div>

            {/* AI SMART ANALYST PANEL (GEMINI POWERED) */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              <div className="bg-gradient-to-br from-slate-900 via-indigo-950/20 to-slate-950 border border-indigo-950/40 p-6 rounded-2xl flex flex-col gap-6 shadow-xl relative overflow-hidden">
                <div className="absolute top-0 right-0 p-8 opacity-5">
                  <Sparkles className="h-44 w-44 text-indigo-500" />
                </div>

                <div className="flex items-start justify-between">
                  <div className="flex items-center gap-3">
                    <div className="h-10 w-10 rounded-xl bg-indigo-500/10 border border-indigo-500/20 flex items-center justify-center text-indigo-400">
                      <Sparkles className="h-5 w-5 animate-pulse" />
                    </div>
                    <div>
                      <h3 className="text-base font-bold text-white font-display">AI Smart City safety Officer</h3>
                      <p className="text-xs text-slate-400">Deep pattern synthesis using Gemini LLM reasoning model</p>
                    </div>
                  </div>

                  <button
                    onClick={handleGenerateAIInsights}
                    disabled={loadingAI}
                    className="flex items-center gap-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 disabled:text-slate-500 px-4 py-2.5 rounded-lg shadow-lg shadow-indigo-600/15 border border-indigo-500/20 transition-all cursor-pointer"
                  >
                    {loadingAI ? (
                      <>
                        <RefreshCw className="h-3.5 w-3.5 animate-spin" /> Compiling...
                      </>
                    ) : (
                      <>
                        <Brain className="h-3.5 w-3.5" /> Synthesize Deep Insights
                      </>
                    )}
                  </button>
                </div>

                {/* AI response content */}
                <div className="bg-slate-950/80 border border-slate-900 rounded-xl p-5 min-h-[300px] flex flex-col">
                  {loadingAI ? (
                    <div className="flex-1 flex flex-col items-center justify-center gap-3 text-slate-400 p-8 text-center">
                      <RefreshCw className="h-8 w-8 text-indigo-400 animate-spin" />
                      <p className="text-xs font-mono font-medium">Querying server-side model: gemini-3.5-flash...</p>
                      <p className="text-[11px] text-slate-500 max-w-sm">Generating comprehensive matrix correlations, weather risk factors, and actionable city safety drafts.</p>
                    </div>
                  ) : aiInsights ? (
                    <div className="prose prose-invert prose-xs max-w-none text-slate-300 space-y-4 font-sans text-xs leading-relaxed">
                      {/* Formatted markdown text */}
                      {aiInsights.split('\n').map((line, idx) => {
                        if (line.startsWith('###')) {
                          return <h4 key={idx} className="text-sm font-bold text-indigo-300 mt-4 border-b border-slate-900 pb-1 font-display uppercase tracking-wide">{line.replace('###', '').trim()}</h4>;
                        }
                        if (line.startsWith('##')) {
                          return <h3 key={idx} className="text-base font-bold text-white mt-5 font-display uppercase">{line.replace('##', '').trim()}</h3>;
                        }
                        if (line.startsWith('-')) {
                          return (
                            <div key={idx} className="flex gap-2.5 ml-1 my-1 text-slate-300">
                              <span className="text-indigo-400 font-bold shrink-0">&bull;</span>
                              <span>{line.replace('-', '').trim()}</span>
                            </div>
                          );
                        }
                        return <p key={idx} className="text-slate-300 my-1">{line}</p>;
                      })}
                    </div>
                  ) : (
                    <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 gap-2">
                      <Sparkles className="h-10 w-10 text-slate-700" />
                      <p className="text-xs font-semibold text-slate-400">AI Sentry Insights Queue Empty</p>
                      <p className="text-[10px] text-slate-600 max-w-xs">Click the button above to request the server-side Gemini-3.5-flash model to synthesize traffic patterns and issue Smart-City recommendations based on active database records.</p>
                    </div>
                  )}
                </div>
              </div>

              {/* Preventative Recommendation static cards */}
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-xl flex flex-col gap-4">
                <h3 className="text-sm font-bold text-white uppercase tracking-wide border-b border-slate-900 pb-3 font-display">Actionable Prevention Rules (Policy Engines)</h3>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 text-xs">
                  <div className="p-4 bg-rose-950/10 border border-rose-950/20 rounded-xl flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-rose-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-rose-300">Excessive Speed Zones</h4>
                      <p className="text-slate-400 mt-1">If speed-related fatal logs exceed 30%, install automated speed cameras, speed breakers, and radar boards on direct links.</p>
                    </div>
                  </div>

                  <div className="p-4 bg-indigo-950/10 border border-indigo-950/20 rounded-xl flex gap-3">
                    <Compass className="h-5 w-5 text-indigo-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-indigo-300">Poor Lighting/Night Risks</h4>
                      <p className="text-slate-400 mt-1">For late-night collisions, recommend upgrading public corridors to solar-powered high-intensity LED street illumination.</p>
                    </div>
                  </div>

                  <div className="p-4 bg-amber-950/10 border border-amber-950/20 rounded-xl flex gap-3">
                    <AlertTriangle className="h-5 w-5 text-amber-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-amber-300">Rain & Monsoon Wet Friction</h4>
                      <p className="text-slate-400 mt-1">During rainfall cycles, deploy smart advisory warning signs on highway corridors and maintain deep pothole filling schedules.</p>
                    </div>
                  </div>

                  <div className="p-4 bg-emerald-950/10 border border-emerald-950/20 rounded-xl flex gap-3">
                    <ShieldCheck className="h-5 w-5 text-emerald-400 shrink-0 mt-0.5" />
                    <div>
                      <h4 className="font-bold text-emerald-300">Critical Crossroads</h4>
                      <p className="text-slate-400 mt-1">Junction density issues require traffic signal installations, wider roundabouts, and pedestrian subways to segregate traffic.</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 3: ACCIDENT HOTSPOT MAP & DETECTOR ==================== */}
        {currentTab === 'hotspots' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
            {/* Left controller: list of clusters/hotspots */}
            <div className="lg:col-span-4 flex flex-col gap-4 max-h-[550px] overflow-y-auto">
              <div className="bg-slate-900/40 border border-slate-900 p-4 rounded-xl flex flex-col gap-2 sticky top-0 bg-slate-950 z-10">
                <h3 className="text-xs font-bold text-slate-300 uppercase tracking-widest font-mono">Clustering Analysis</h3>
                <h2 className="text-sm font-bold text-white font-display">HOTSPOT DETECTION (DBSCAN)</h2>
                <p className="text-[11px] text-slate-400">This module groups coordinate clusters within 1.5km to define geographical risks based on accident recurrence.</p>
              </div>

              {hotspots.length === 0 ? (
                <div className="p-6 bg-slate-900/10 border border-slate-900 text-center rounded-xl text-xs text-slate-500">
                  No hotspots detected in the current data registries. Try seeding the database.
                </div>
              ) : (
                hotspots.map((hs) => {
                  const active = activeHotspotId === hs.id;
                  const border = hs.riskLevel === 'High' ? 'border-rose-500/20' : (hs.riskLevel === 'Medium' ? 'border-amber-500/20' : 'border-yellow-500/20');
                  const text = hs.riskLevel === 'High' ? 'text-rose-400' : (hs.riskLevel === 'Medium' ? 'text-amber-400' : 'text-yellow-400');
                  const bg = hs.riskLevel === 'High' ? 'bg-rose-500/5' : (hs.riskLevel === 'Medium' ? 'bg-amber-500/5' : 'bg-yellow-500/5');

                  return (
                    <div 
                      key={hs.id}
                      onClick={() => setActiveHotspotId(active ? undefined : hs.id)}
                      className={`p-4 border rounded-xl transition-all cursor-pointer flex flex-col gap-2 text-xs ${border} ${bg} ${
                        active ? 'ring-2 ring-indigo-500/40 bg-slate-900' : 'hover:bg-slate-900/30'
                      }`}
                    >
                      <div className="flex items-center justify-between">
                        <span className={`font-bold font-mono text-[10px] px-1.5 py-0.5 rounded ${
                          hs.riskLevel === 'High' ? 'bg-rose-500/10 text-rose-400' :
                          hs.riskLevel === 'Medium' ? 'bg-amber-500/10 text-amber-400' :
                          'bg-yellow-500/10 text-yellow-400'
                        }`}>
                          {hs.riskLevel.toUpperCase()} RISK
                        </span>
                        <span className="text-slate-500 font-mono text-[9px]">Cluster: {hs.accidentCount} logs</span>
                      </div>
                      
                      <p className="font-semibold text-white text-xs">{hs.location}</p>
                      
                      <div className="flex items-center justify-between text-[10px] text-slate-400 pt-1 border-t border-slate-900/50">
                        <span>Fatalities: <strong className="text-white">{hs.fatalCount}</strong></span>
                        <span className="text-indigo-400 font-bold hover:underline">Plot location &rarr;</span>
                      </div>
                    </div>
                  );
                })
              )}
            </div>

            {/* Right Leaflet Full Map View */}
            <div className="lg:col-span-8 h-[550px] bg-slate-900/40 border border-slate-900 p-3 rounded-xl overflow-hidden relative">
              <AccidentMap 
                records={accidents} 
                hotspots={hotspots}
                highlightHotspotId={activeHotspotId}
                centerCity={selectedCity !== 'All' ? selectedCity : undefined}
              />
            </div>
          </div>
        )}

        {/* ==================== TAB 4: ML RISK PREDICTION MODULE ==================== */}
        {currentTab === 'predict' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
            {/* Input Form Column */}
            <div className="lg:col-span-5 bg-slate-900/40 border border-slate-900 p-5 rounded-2xl flex flex-col gap-5">
              <div>
                <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono">Analytical Modeling</h3>
                <h2 className="text-sm font-bold text-white font-display uppercase mt-1">Accident Risk Predictor</h2>
                <p className="text-[11px] text-slate-400 mt-1">Enter specific parameters below. Our machine learning core will calculate the statistical risk of occurrence and display probability distributions.</p>
              </div>

              <form onSubmit={handlePredictRisk} className="flex flex-col gap-4 text-xs text-slate-300">
                <div className="flex flex-col gap-1.5">
                  <label className="font-semibold">Location / Segment Name</label>
                  <input 
                    type="text" 
                    value={predictLocation} 
                    onChange={(e) => setPredictLocation(e.target.value)}
                    placeholder="Enter street/highway junction"
                    className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500"
                    required
                  />
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold">Weather Condition</label>
                    <select 
                      value={predictWeather} 
                      onChange={(e) => setPredictWeather(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                    >
                      <option value="Clear">Clear</option>
                      <option value="Rain">Rain (Wet slick)</option>
                      <option value="Fog">Fog (Low visibility)</option>
                      <option value="Cloudy">Cloudy</option>
                      <option value="Mist">Mist</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold">Time of Day</label>
                    <select 
                      value={predictTime} 
                      onChange={(e) => setPredictTime(e.target.value as any)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                    >
                      <option value="Morning">Morning (05:00 - 12:00)</option>
                      <option value="Afternoon">Afternoon (12:00 - 17:00)</option>
                      <option value="Evening">Evening (17:00 - 21:00)</option>
                      <option value="Night">Night (21:00 - 05:00)</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold">Road Surface</label>
                    <select 
                      value={predictRoad} 
                      onChange={(e) => setPredictRoad(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                    >
                      <option value="Dry">Dry</option>
                      <option value="Wet">Wet / Damp</option>
                      <option value="Potholes">Potholes / Damaged</option>
                      <option value="Under Construction">Under Construction</option>
                      <option value="Sandy">Sandy / Loose Gravel</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold">Traffic Density</label>
                    <select 
                      value={predictTraffic} 
                      onChange={(e) => setPredictTraffic(e.target.value as any)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                    >
                      <option value="Low">Low Density</option>
                      <option value="Medium">Medium Density</option>
                      <option value="High">High Gridlock</option>
                    </select>
                  </div>
                </div>

                <div className="grid grid-cols-2 gap-4">
                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold">Target Vehicle Type</label>
                    <select 
                      value={predictVehicle} 
                      onChange={(e) => setPredictVehicle(e.target.value)}
                      className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                    >
                      <option value="Car">Car / Sedan</option>
                      <option value="Two-Wheeler">Two-Wheeler / Bike</option>
                      <option value="Truck">Heavy Truck</option>
                      <option value="Bus">Public Bus</option>
                      <option value="Auto-Rickshaw">Auto-Rickshaw</option>
                    </select>
                  </div>

                  <div className="flex flex-col gap-1.5">
                    <label className="font-semibold text-indigo-400">ML Classifier Core</label>
                    <select 
                      value={predictAlgo} 
                      onChange={(e) => setPredictAlgo(e.target.value as any)}
                      className="bg-indigo-950 border border-indigo-900/40 rounded-lg p-2 text-indigo-200 cursor-pointer focus:outline-none font-bold"
                    >
                      <option value="Random Forest">Random Forest Classifier</option>
                      <option value="Decision Tree">Decision Tree Classifier</option>
                      <option value="Logistic Regression">Logistic Regression (Softmax)</option>
                    </select>
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={predicting}
                  className="mt-2 w-full flex items-center justify-center gap-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 px-4 py-3 rounded-lg shadow-lg shadow-indigo-600/10 cursor-pointer transition-colors"
                >
                  {predicting ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" /> Training weights & calculating...
                    </>
                  ) : (
                    <>
                      <Brain className="h-4 w-4" /> Run Prediction Model
                    </>
                  )}
                </button>
              </form>
            </div>

            {/* Results Output Column */}
            <div className="lg:col-span-7 flex flex-col gap-6">
              <div className="bg-slate-900/40 border border-slate-900 p-6 rounded-2xl flex flex-col gap-6 shadow-xl relative overflow-hidden">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Prediction Diagnostics</h3>

                {predictionResult ? (
                  <div className="flex flex-col gap-6 animate-fade-in">
                    {/* Top Result Banner */}
                    <div className="p-5 rounded-xl bg-slate-950/80 border border-slate-900 flex flex-col md:flex-row items-center justify-between gap-4">
                      <div>
                        <span className="text-[10px] font-mono text-slate-500 uppercase">Algorithm Output: {predictionResult.algorithm}</span>
                        <h4 className="text-sm font-semibold text-slate-300 mt-0.5">Predicted Segment Risk:</h4>
                        <div className="flex items-center gap-2 mt-1.5">
                          <span className={`text-base font-extrabold tracking-wider uppercase font-display px-2 py-0.5 rounded ${
                            predictionResult.predictedRisk === 'High' ? 'bg-rose-500/10 text-rose-400 border border-rose-500/20' :
                            predictionResult.predictedRisk === 'Medium' ? 'bg-amber-500/10 text-amber-400 border border-amber-500/20' :
                            'bg-emerald-500/10 text-emerald-400 border border-emerald-500/20'
                          }`}>
                            {predictionResult.predictedRisk} Risk
                          </span>
                        </div>
                      </div>

                      {/* Probability Percentage Dial indicator */}
                      <div className="text-center bg-slate-900/50 p-4 rounded-lg border border-slate-800 min-w-[150px]">
                        <span className="text-[9px] uppercase tracking-wider text-slate-500 font-bold block">CONFIDENCE PROBABILITY</span>
                        <span className="text-3xl font-extrabold font-display mt-1 block text-indigo-400">
                          {Math.round(predictionResult.probabilities[predictionResult.predictedRisk] * 100)}%
                        </span>
                      </div>
                    </div>

                    {/* Probability Breakdown Matrix */}
                    <div className="flex flex-col gap-3">
                      <h4 className="text-xs font-semibold text-slate-400 uppercase font-mono">Class Probabilities (Softmax Distribution)</h4>
                      
                      {/* High Class */}
                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
                          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-rose-500 inline-block"></span> High Severity Risk</span>
                          <span className="font-mono">{Math.round(predictionResult.probabilities.High * 100)}%</span>
                        </div>
                        <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-900">
                          <div className="bg-rose-500 h-full transition-all duration-500" style={{ width: `${predictionResult.probabilities.High * 100}%` }}></div>
                        </div>
                      </div>

                      {/* Medium Class */}
                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
                          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-amber-500 inline-block"></span> Medium Trauma Risk</span>
                          <span className="font-mono">{Math.round(predictionResult.probabilities.Medium * 100)}%</span>
                        </div>
                        <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-900">
                          <div className="bg-amber-500 h-full transition-all duration-500" style={{ width: `${predictionResult.probabilities.Medium * 100}%` }}></div>
                        </div>
                      </div>

                      {/* Low Class */}
                      <div className="flex flex-col gap-1.5">
                        <div className="flex items-center justify-between text-[11px] font-semibold text-slate-300">
                          <span className="flex items-center gap-1.5"><span className="w-2 h-2 rounded-full bg-emerald-500 inline-block"></span> Low Risk / Safe Segment</span>
                          <span className="font-mono">{Math.round(predictionResult.probabilities.Low * 100)}%</span>
                        </div>
                        <div className="w-full bg-slate-950 rounded-full h-2 overflow-hidden border border-slate-900">
                          <div className="bg-emerald-500 h-full transition-all duration-500" style={{ width: `${predictionResult.probabilities.Low * 100}%` }}></div>
                        </div>
                      </div>
                    </div>

                    {/* Classifier technical report */}
                    <div className="p-4 bg-slate-950/40 border border-slate-900 rounded-xl text-[11px] text-slate-400 flex flex-col gap-1.5 leading-relaxed">
                      <p className="font-bold text-slate-300 uppercase tracking-wider text-[10px]">Algorithm Diagnostics:</p>
                      <p>
                        {predictionResult.algorithm === 'Random Forest' && 'Random Forest Classifier bootstrapped 5 distinct decision trees with random features to produce this ensemble average. Resilient to feature outliers.'}
                        {predictionResult.algorithm === 'Decision Tree' && 'The ID3 Decision Tree algorithm calculated Information Gain splits across weather patterns, location metrics and surface friction indexes to isolate terminal leaf node probabilities.'}
                        {predictionResult.algorithm === 'Logistic Regression' && 'Logistic Regression one-hot encoded the categorical inputs into a flat feature space and optimized softmax scores using epoch cross-entropy gradient descents.'}
                      </p>
                    </div>
                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 gap-2 min-h-[300px]">
                    <Brain className="h-10 w-10 text-slate-700 animate-pulse" />
                    <p className="text-xs font-semibold text-slate-400">Prediction Engine Standby</p>
                    <p className="text-[10px] text-slate-600 max-w-xs">Provide traffic parameters in the input card on the left and select "Run Prediction Model" to compute real machine learning outcomes based on active database logs.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 5: SAFE ROUTE RECOMMENDATION ==================== */}
        {currentTab === 'routes' && (
          <div className="grid grid-cols-1 lg:grid-cols-12 gap-6 animate-fade-in">
            {/* Input Form Column */}
            <div className="lg:col-span-4 bg-slate-900/40 border border-slate-900 p-5 rounded-2xl flex flex-col gap-4">
              <div>
                <h3 className="text-xs font-bold text-indigo-400 uppercase tracking-widest font-mono">Safety-First Routing</h3>
                <h2 className="text-sm font-bold text-white font-display uppercase mt-1">Route Safety Planner</h2>
                <p className="text-[11px] text-slate-400 mt-1">Our algorithm analyzes historical traffic incidents near coordinate pathways to suggest safer alternatives.</p>
              </div>

              <form onSubmit={handleCalculateRoutes} className="flex flex-col gap-4 text-xs text-slate-300">
                <div className="flex flex-col gap-1.5">
                  <label className="font-semibold">Source Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
                    <input 
                      type="text" 
                      value={routeSource} 
                      onChange={(e) => setRouteSource(e.target.value)}
                      placeholder="e.g. Silk Board Junction, Bangalore"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 pl-9 text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>
                </div>

                <div className="flex flex-col gap-1.5">
                  <label className="font-semibold">Destination Location</label>
                  <div className="relative">
                    <MapPin className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
                    <input 
                      type="text" 
                      value={routeDest} 
                      onChange={(e) => setRouteDest(e.target.value)}
                      placeholder="e.g. Hebbal Flyover, Bangalore"
                      className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 pl-9 text-white focus:outline-none focus:border-indigo-500"
                      required
                    />
                  </div>
                </div>

                <button
                  type="submit"
                  disabled={calculatingRoute}
                  className="w-full flex items-center justify-center gap-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 disabled:bg-slate-800 px-4 py-2.5 rounded-lg shadow-lg shadow-indigo-600/10 cursor-pointer transition-colors"
                >
                  {calculatingRoute ? (
                    <>
                      <RefreshCw className="h-4 w-4 animate-spin" /> Querying historical safety weights...
                    </>
                  ) : (
                    <>
                      <Compass className="h-4 w-4" /> Calculate Safest Routes
                    </>
                  )}
                </button>
              </form>

              {/* Suggestions template helper */}
              <div className="p-3 bg-slate-950/60 border border-slate-900 rounded-xl flex flex-col gap-2 text-[10px] text-slate-500">
                <span className="font-bold uppercase tracking-wider text-slate-400">Try these routes to test the system:</span>
                <div className="flex flex-col gap-1.5 font-semibold">
                  <button type="button" onClick={() => { setRouteSource('Silk Board, Bangalore'); setRouteDest('Bellandur, Bangalore'); }} className="text-left text-indigo-400 hover:underline">Silk Board &rarr; Bellandur (Bangalore)</button>
                  <button type="button" onClick={() => { setRouteSource('Sion Circle, Mumbai'); setRouteDest('Saki Naka, Mumbai'); }} className="text-left text-indigo-400 hover:underline">Sion Circle &rarr; Saki Naka (Mumbai)</button>
                  <button type="button" onClick={() => { setRouteSource('Dhaula Kuan, Delhi'); setRouteDest('AIIMS, Delhi'); }} className="text-left text-indigo-400 hover:underline">Dhaula Kuan &rarr; AIIMS (Delhi)</button>
                </div>
              </div>
            </div>

            {/* Live routing map & text results */}
            <div className="lg:col-span-8 flex flex-col gap-4">
              <div className="bg-slate-900/40 border border-slate-900 p-5 rounded-2xl flex flex-col gap-5">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono border-b border-slate-900 pb-2">Active routing recommendations</h3>

                {routingResult ? (
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-5 animate-fade-in">
                    
                    {/* Visual list of route options */}
                    <div className="flex flex-col gap-4">
                      {routingResult.routes.map((route, index) => {
                        const isRec = index === 0;
                        const border = isRec ? 'border-emerald-500/30 bg-emerald-500/5' : 'border-rose-500/15 bg-rose-500/5';
                        const text = isRec ? 'text-emerald-400' : 'text-rose-400';
                        
                        return (
                          <div key={route.id} className={`p-4 border rounded-xl flex flex-col gap-2.5 text-xs ${border}`}>
                            <div className="flex items-center justify-between">
                              <span className={`font-mono text-[9px] font-bold px-1.5 py-0.5 rounded ${isRec ? 'bg-emerald-500/10 text-emerald-400' : 'bg-rose-500/10 text-rose-400'}`}>
                                {isRec ? 'RECOMMENDED SAFE ROUTE' : 'RISKY DIRECT PATH'}
                              </span>
                              <span className="font-mono text-slate-400">{route.distance} km</span>
                            </div>

                            <p className="font-bold text-white text-xs">{route.name}</p>

                            <div className="grid grid-cols-3 gap-2 text-center text-[10px] bg-slate-950/40 p-2.5 rounded-lg border border-slate-900">
                              <div>
                                <span className="text-slate-500 block text-[9px] font-bold uppercase">EST TIME</span>
                                <span className="text-white font-mono font-bold mt-0.5 block">{route.duration} m</span>
                              </div>
                              <div>
                                <span className="text-slate-500 block text-[9px] font-bold uppercase">SAFETY INDEX</span>
                                <span className={`${text} font-mono font-bold mt-0.5 block`}>{route.safetyFactor}</span>
                              </div>
                              <div>
                                <span className="text-slate-500 block text-[9px] font-bold uppercase">HIST RISK</span>
                                <span className="text-white font-mono font-bold mt-0.5 block">{route.accidentsEnRouteCount} logs</span>
                              </div>
                            </div>
                          </div>
                        );
                      })}

                      {/* AI logic breakdown */}
                      <div className="p-4 bg-slate-950/80 border border-slate-900 rounded-xl text-xs text-slate-300 leading-relaxed flex flex-col gap-1.5">
                        <span className="font-bold text-indigo-400 font-display flex items-center gap-1">
                          <Sparkles className="h-3.5 w-3.5" /> ROUTING LOGIC REPORT:
                        </span>
                        <p className="text-[11px] text-slate-300">{routingResult.recommendationReason}</p>
                      </div>
                    </div>

                    {/* Integrated mini mapping view to display route polylines */}
                    <div className="h-[320px] md:h-auto rounded-xl overflow-hidden border border-slate-900 relative">
                      <AccidentMap 
                        records={accidents} 
                        hotspots={hotspots}
                        routes={routingResult.routes}
                      />
                    </div>

                  </div>
                ) : (
                  <div className="flex-1 flex flex-col items-center justify-center p-8 text-center text-slate-500 gap-2 min-h-[300px]">
                    <Compass className="h-10 w-10 text-slate-700 animate-pulse" />
                    <p className="text-xs font-semibold text-slate-400">Routing Core Standby</p>
                    <p className="text-[10px] text-slate-600 max-w-xs">Provide a source and destination address on the left and click "Calculate Safest Routes" to calculate real safety detours plotted on our smart-city coordinate systems.</p>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}

        {/* ==================== TAB 6: REPORTS & EXPORT TO PDF ==================== */}
        {currentTab === 'reports' && (
          <div className="flex flex-col gap-6 animate-fade-in">
            {/* Search/Filter Controls */}
            <div className="no-print bg-slate-900/40 border border-slate-900 p-5 rounded-2xl flex flex-col md:flex-row items-center justify-between gap-4">
              <div className="flex flex-wrap items-center gap-4 w-full md:w-auto">
                {/* Keyword Search */}
                <div className="relative w-full md:w-60">
                  <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-slate-500" />
                  <input 
                    type="text" 
                    value={searchKeyword} 
                    onChange={(e) => setSearchKeyword(e.target.value)}
                    placeholder="Search location, cause, ID..."
                    className="w-full bg-slate-950 border border-slate-800 rounded-lg p-2 pl-9 text-xs text-white focus:outline-none focus:border-indigo-500"
                  />
                </div>

                {/* Severity Filter */}
                <select 
                  value={severityFilter} 
                  onChange={(e) => setSeverityFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 cursor-pointer focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">All Severity Levels</option>
                  <option value="Fatal">Fatal accidents</option>
                  <option value="Severe">Severe injuries</option>
                  <option value="Minor">Minor incidents</option>
                </select>

                {/* Cause Filter */}
                <select 
                  value={causeFilter} 
                  onChange={(e) => setCauseFilter(e.target.value)}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-xs text-slate-300 cursor-pointer focus:outline-none focus:border-indigo-500"
                >
                  <option value="All">All Causes</option>
                  <option value="Overspeeding">Overspeeding</option>
                  <option value="Drunk Driving">Drunk Driving</option>
                  <option value="Traffic Violation">Traffic Violation</option>
                  <option value="Poor Road Conditions">Poor Road Conditions</option>
                  <option value="Distracted Driving">Distracted Driving</option>
                </select>
              </div>

              {/* Action Trigger */}
              <button 
                onClick={() => window.print()}
                className="flex items-center gap-1.5 text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 px-4.5 py-2.5 rounded-lg shadow-lg shadow-indigo-600/10 cursor-pointer transition-colors shrink-0"
              >
                <FileText className="h-4 w-4" /> Export Report Dossier (PDF)
              </button>
            </div>

            {/* Print Layout Document Container */}
            <div className="bg-slate-900/20 border border-slate-900 p-6 md:p-8 rounded-2xl flex flex-col gap-6 print-card text-slate-300">
              
              {/* Document Header (Always Shown) */}
              <div className="flex flex-col md:flex-row md:items-center justify-between border-b border-slate-800 pb-6 gap-4">
                <div>
                  <span className="text-[10px] font-mono font-bold text-indigo-400 bg-indigo-500/10 px-2 py-0.5 rounded border border-indigo-500/20 uppercase tracking-widest inline-block mb-2">SMART CITY MUNICIPAL REPORT</span>
                  <h2 className="text-xl font-bold text-white font-display uppercase">Traffic Safety Analysis & Risk Dossier</h2>
                  <p className="text-xs text-slate-400 mt-1">Compiled on {new Date().toISOString().split('T')[0]} • Scope City: <span className="font-semibold text-slate-300">{selectedCity === 'All' ? 'All Metros' : `${selectedCity} Metro`}</span></p>
                </div>
                <div className="text-left md:text-right text-xs">
                  <p className="text-slate-400">Total Registered Accidents: <strong className="text-white font-mono">{filteredAccidents.length}</strong></p>
                  <p className="text-slate-400">Deceased / Fatals: <strong className="text-rose-400 font-mono">{filteredAccidents.filter(r => r.severityLevel === 'Fatal').length}</strong></p>
                </div>
              </div>

              {/* Summary stats visual grids (Print-optimized card) */}
              <div className="grid grid-cols-2 md:grid-cols-4 gap-4 p-4 bg-slate-950/40 border border-slate-900/60 rounded-xl print-card">
                <div>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Scope Metro Filter</span>
                  <span className="text-xs font-bold text-indigo-400 mt-1 block">{selectedCity === 'All' ? 'All Cities' : selectedCity}</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Severity Breakdown</span>
                  <span className="text-xs font-bold text-white mt-1 block">
                    F: {filteredAccidents.filter(r => r.severityLevel === 'Fatal').length} / S: {filteredAccidents.filter(r => r.severityLevel === 'Severe').length} / M: {filteredAccidents.filter(r => r.severityLevel === 'Minor').length}
                  </span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Primary Risk Trigger</span>
                  <span className="text-xs font-bold text-amber-500 mt-1 block">Overspeeding / Violations</span>
                </div>
                <div>
                  <span className="text-[10px] text-slate-500 uppercase tracking-wider block font-bold">Report Status Code</span>
                  <span className="text-xs font-bold text-emerald-400 mt-1 block font-mono">DRAFT-AUTOGEN-2026</span>
                </div>
              </div>

              {/* Data Table of Accident Logs */}
              <div className="flex flex-col gap-3">
                <h3 className="text-xs font-bold text-slate-400 uppercase tracking-widest font-mono">Registered Accident Records</h3>
                <div className="overflow-x-auto border border-slate-900 rounded-xl">
                  <table className="w-full text-left border-collapse text-xs">
                    <thead>
                      <tr className="bg-slate-950/80 border-b border-slate-900 text-slate-400 font-mono">
                        <th className="p-3">ID</th>
                        <th className="p-3">Date/Time</th>
                        <th className="p-3">Location</th>
                        <th className="p-3">Severity</th>
                        <th className="p-3">Primary Cause</th>
                        <th className="p-3 text-center">Casualties</th>
                      </tr>
                    </thead>
                    <tbody className="divide-y divide-slate-900/50">
                      {filteredAccidents.length === 0 ? (
                        <tr>
                          <td colSpan={6} className="p-6 text-center text-slate-500 font-mono">No matching accident records found.</td>
                        </tr>
                      ) : (
                        filteredAccidents.map((rec) => (
                          <tr key={rec.accidentId} className="hover:bg-slate-900/20">
                            <td className="p-3 font-mono font-bold text-slate-400">{rec.accidentId}</td>
                            <td className="p-3 font-mono text-slate-400">{rec.date} {rec.time}</td>
                            <td className="p-3 font-semibold text-white">{rec.location}</td>
                            <td className="p-3">
                              <span className={`px-1.5 py-0.5 rounded text-[10px] font-bold ${
                                rec.severityLevel === 'Fatal' ? 'bg-rose-500/10 text-rose-400' :
                                rec.severityLevel === 'Severe' ? 'bg-amber-500/10 text-amber-400' :
                                'bg-yellow-500/10 text-yellow-400'
                              }`}>
                                {rec.severityLevel}
                              </span>
                            </td>
                            <td className="p-3 text-slate-300">{rec.accidentCause}</td>
                            <td className="p-3 text-center font-bold text-white font-mono">{rec.numberOfCasualties}</td>
                          </tr>
                        ))
                      )}
                    </tbody>
                  </table>
                </div>
              </div>

              {/* Action Recommendations block inside report */}
              <div className="p-5 bg-slate-950/40 border border-slate-900 rounded-xl print-card flex flex-col gap-3">
                <h4 className="text-xs font-bold text-white uppercase tracking-widest font-mono flex items-center gap-1.5">
                  <ShieldCheck className="h-4 w-4 text-emerald-400" /> Municipal Safety Recommendations
                </h4>
                <ul className="list-disc list-inside space-y-2 text-xs text-slate-400 leading-relaxed">
                  <li><strong>Target High Severity Zones</strong>: Immediate deployment of active speed camera gates at the first five hotspots on our ranking board.</li>
                  <li><strong>Pedestrian Safeguards</strong>: Establish skywalks or underground pathways where heavy traffic density junctions display recurring minor auto-rickshaw/pedestrian collisions.</li>
                  <li><strong>Active LED Corridors</strong>: Prioritize central budget requests to provide high-voltage grid lighting along express bypass links, addressing nighttime drunk driving hazards.</li>
                </ul>
              </div>

            </div>
          </div>
        )}

      </div>

      {/* ==================== ADMINISTRATIVE LOGIN MODAL ==================== */}
      {showLoginModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-sm w-full flex flex-col gap-5 shadow-2xl relative">
            <button 
              onClick={() => setShowLoginModal(false)}
              className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
            
            <div className="text-center">
              <div className="h-10 w-10 bg-indigo-500/10 text-indigo-400 border border-indigo-500/20 rounded-xl flex items-center justify-center mx-auto mb-3">
                <Lock className="h-5 w-5 animate-pulse" />
              </div>
              <h3 className="text-sm font-bold text-white font-display uppercase tracking-wide">Administrator Portal Login</h3>
              <p className="text-xs text-slate-400 mt-1">Authenticate credentials to gain upload and configuration controls.</p>
            </div>

            {authError && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] rounded-lg">
                {authError}
              </div>
            )}

            <form onSubmit={handleLogin} className="flex flex-col gap-3 text-xs">
              <div className="flex flex-col gap-1">
                <label className="text-slate-400">Username</label>
                <input 
                  type="text" 
                  value={username}
                  onChange={(e) => setUsername(e.target.value)}
                  placeholder="Enter 'admin'"
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-medium"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="text-slate-400">Password</label>
                <input 
                  type="password" 
                  value={password}
                  onChange={(e) => setPassword(e.target.value)}
                  placeholder="Enter 'admin123'"
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none focus:border-indigo-500 font-medium"
                  required
                />
              </div>

              <button 
                type="submit"
                className="mt-2 w-full text-xs font-bold text-white bg-indigo-600 hover:bg-indigo-500 px-4 py-2.5 rounded-lg transition-colors cursor-pointer"
              >
                Sign In
              </button>
            </form>

            <div className="p-3 bg-slate-950/40 border border-slate-900 rounded-xl text-center text-[10px] text-slate-500">
              <span className="font-bold block uppercase text-slate-400 mb-0.5">Mock Security Credentials:</span>
              Username: <strong className="text-indigo-400">admin</strong> / Password: <strong className="text-indigo-400">admin123</strong>
            </div>
          </div>
        </div>
      )}

      {/* ==================== BULK CSV UPLOAD MODAL ==================== */}
      {showUploadModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-xl w-full flex flex-col gap-5 shadow-2xl relative">
            <button 
              onClick={() => setShowUploadModal(false)}
              className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
            
            <div>
              <h3 className="text-sm font-bold text-white font-display uppercase tracking-wide">Bulk Accident Registries (CSV format)</h3>
              <p className="text-xs text-slate-400 mt-1">Upload or paste comma-separated registers. Standard column structures must match the template mapping below.</p>
            </div>

            {uploadSuccess && (
              <div className="p-3 bg-emerald-500/10 border border-emerald-500/20 text-emerald-400 text-xs rounded-lg">
                {uploadSuccess}
              </div>
            )}

            {uploadErrors.length > 0 && (
              <div className="p-3 bg-rose-500/10 border border-rose-500/20 text-rose-400 text-[10px] rounded-lg max-h-24 overflow-y-auto space-y-1">
                <span className="font-bold uppercase tracking-wider block">Upload Issues:</span>
                {uploadErrors.map((err, idx) => <p key={idx}>&bull; {err}</p>)}
              </div>
            )}

            <div className="flex flex-col gap-2.5">
              <div className="flex justify-between items-center text-xs">
                <label className="font-semibold text-slate-300">Paste CSV Contents</label>
                <button 
                  onClick={loadCSVSample}
                  className="text-xs font-bold text-indigo-400 hover:underline cursor-pointer"
                >
                  Load Sample Template
                </button>
              </div>
              <textarea 
                value={csvContent}
                onChange={(e) => setCsvContent(e.target.value)}
                placeholder="Accident ID,Date,Time,Location,Latitude,Longitude,Weather condition,Road condition,Vehicle type,Accident cause,Severity level,Number of casualties..."
                className="w-full bg-slate-950 border border-slate-800 rounded-lg p-3 text-xs text-white focus:outline-none focus:border-indigo-500 h-44 font-mono"
              />
            </div>

            <div className="flex gap-2 justify-end text-xs font-semibold">
              <button 
                onClick={() => setShowUploadModal(false)}
                className="bg-slate-950 hover:bg-slate-900 text-slate-300 px-4 py-2 rounded-lg border border-slate-800 cursor-pointer"
              >
                Cancel
              </button>
              <button 
                onClick={handleCSVUpload}
                disabled={loading}
                className="bg-indigo-600 hover:bg-indigo-500 text-white px-5 py-2 rounded-lg shadow-lg shadow-indigo-600/15 cursor-pointer disabled:bg-slate-800 disabled:text-slate-500"
              >
                {loading ? 'Processing...' : 'Commit Upload'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* ==================== MANUAL LOG INCIDENT MODAL ==================== */}
      {showAddModal && (
        <div className="fixed inset-0 bg-slate-950/80 backdrop-blur-sm flex items-center justify-center z-50 p-4">
          <div className="bg-slate-900 border border-slate-800 p-6 rounded-2xl max-w-lg w-full flex flex-col gap-4 shadow-2xl relative">
            <button 
              onClick={() => setShowAddModal(false)}
              className="absolute top-3 right-3 text-slate-500 hover:text-slate-300 cursor-pointer"
            >
              <X className="h-4 w-4" />
            </button>
            
            <div>
              <h3 className="text-sm font-bold text-white font-display uppercase tracking-wide">Register Single Accident Log</h3>
              <p className="text-xs text-slate-400">Inject a single coordinate point manually into our active municipal databases.</p>
            </div>

            <form onSubmit={handleAddRecord} className="grid grid-cols-2 gap-4 text-xs text-slate-300">
              <div className="flex flex-col gap-1">
                <label className="font-semibold">Incident Date</label>
                <input 
                  type="date" 
                  value={newRecord.date}
                  onChange={(e) => setNewRecord({ ...newRecord, date: e.target.value })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Incident Time</label>
                <input 
                  type="time" 
                  value={newRecord.time}
                  onChange={(e) => setNewRecord({ ...newRecord, time: e.target.value })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex flex-col gap-1 col-span-2">
                <label className="font-semibold">Location / Segment Address</label>
                <input 
                  type="text" 
                  value={newRecord.location}
                  onChange={(e) => setNewRecord({ ...newRecord, location: e.target.value })}
                  placeholder="e.g. Silk Board Junction, Bangalore"
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Latitude</label>
                <input 
                  type="number" 
                  step="0.0001"
                  value={newRecord.latitude}
                  onChange={(e) => setNewRecord({ ...newRecord, latitude: Number(e.target.value) })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none font-mono"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Longitude</label>
                <input 
                  type="number" 
                  step="0.0001"
                  value={newRecord.longitude}
                  onChange={(e) => setNewRecord({ ...newRecord, longitude: Number(e.target.value) })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none font-mono"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Weather condition</label>
                <select 
                  value={newRecord.weatherCondition}
                  onChange={(e) => setNewRecord({ ...newRecord, weatherCondition: e.target.value as any })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                >
                  <option value="Clear">Clear</option>
                  <option value="Rain">Rain</option>
                  <option value="Fog">Fog</option>
                  <option value="Cloudy">Cloudy</option>
                  <option value="Mist">Mist</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Road surface condition</label>
                <select 
                  value={newRecord.roadCondition}
                  onChange={(e) => setNewRecord({ ...newRecord, roadCondition: e.target.value as any })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                >
                  <option value="Dry">Dry</option>
                  <option value="Wet">Wet</option>
                  <option value="Potholes">Potholes</option>
                  <option value="Under Construction">Under Construction</option>
                  <option value="Sandy">Sandy</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Vehicle type</label>
                <select 
                  value={newRecord.vehicleType}
                  onChange={(e) => setNewRecord({ ...newRecord, vehicleType: e.target.value as any })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                >
                  <option value="Car">Car</option>
                  <option value="Two-Wheeler">Two-Wheeler</option>
                  <option value="Truck">Truck</option>
                  <option value="Bus">Bus</option>
                  <option value="Auto-Rickshaw">Auto-Rickshaw</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Severity level</label>
                <select 
                  value={newRecord.severityLevel}
                  onChange={(e) => setNewRecord({ ...newRecord, severityLevel: e.target.value as any })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                >
                  <option value="Fatal">Fatal</option>
                  <option value="Severe">Severe</option>
                  <option value="Minor">Minor</option>
                </select>
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Number of casualties</label>
                <input 
                  type="number" 
                  min="0"
                  value={newRecord.numberOfCasualties}
                  onChange={(e) => setNewRecord({ ...newRecord, numberOfCasualties: Number(e.target.value) })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white focus:outline-none font-mono"
                  required
                />
              </div>

              <div className="flex flex-col gap-1">
                <label className="font-semibold">Primary cause factor</label>
                <select 
                  value={newRecord.accidentCause}
                  onChange={(e) => setNewRecord({ ...newRecord, accidentCause: e.target.value as any })}
                  className="bg-slate-950 border border-slate-800 rounded-lg p-2 text-white cursor-pointer focus:outline-none"
                >
                  <option value="Overspeeding">Overspeeding</option>
                  <option value="Drunk Driving">Drunk Driving</option>
                  <option value="Traffic Violation">Traffic Violation</option>
                  <option value="Poor Road Conditions">Poor Road Conditions</option>
                  <option value="Distracted Driving">Distracted Driving</option>
                </select>
              </div>

              <div className="col-span-2 flex gap-2 justify-end font-semibold mt-2">
                <button 
                  type="button" 
                  onClick={() => setShowAddModal(false)}
                  className="bg-slate-950 hover:bg-slate-900 text-slate-300 px-4 py-2 rounded-lg border border-slate-800 cursor-pointer"
                >
                  Cancel
                </button>
                <button 
                  type="submit"
                  className="bg-emerald-600 hover:bg-emerald-500 text-white px-5 py-2 rounded-lg shadow-lg shadow-emerald-600/15 cursor-pointer"
                >
                  Save Record
                </button>
              </div>
            </form>
          </div>
        </div>
      )}

      {/* Footer copyright */}
      <footer className="no-print mt-auto border-t border-slate-900/60 bg-slate-950 p-4 text-center text-[10px] text-slate-500">
        <p>&copy; 2026 Smart City Traffic Analytics Sentry. Built with modern React, Express and Google Gemini AI.</p>
      </footer>
    </div>
  );
}
