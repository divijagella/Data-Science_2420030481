export interface AccidentRecord {
  accidentId: string;
  date: string; // YYYY-MM-DD
  time: string; // HH:MM
  location: string;
  latitude: number;
  longitude: number;
  weatherCondition: 'Clear' | 'Rain' | 'Fog' | 'Cloudy' | 'Mist';
  roadCondition: 'Dry' | 'Wet' | 'Potholes' | 'Under Construction' | 'Sandy';
  vehicleType: 'Two-Wheeler' | 'Car' | 'Truck' | 'Bus' | 'Auto-Rickshaw';
  accidentCause: 'Overspeeding' | 'Drunk Driving' | 'Traffic Violation' | 'Poor Road Conditions' | 'Distracted Driving';
  severityLevel: 'Fatal' | 'Severe' | 'Minor';
  numberOfCasualties: number;
  trafficDensity?: 'Low' | 'Medium' | 'High';
}

export interface PredictionInput {
  location: string;
  weatherCondition: string;
  timeOfDay: 'Morning' | 'Afternoon' | 'Evening' | 'Night';
  roadCondition: string;
  trafficDensity: 'Low' | 'Medium' | 'High';
  vehicleType: string;
}

export interface PredictionResult {
  algorithm: 'Decision Tree' | 'Random Forest' | 'Logistic Regression';
  predictedRisk: 'Low' | 'Medium' | 'High';
  probabilities: {
    Low: number;
    Medium: number;
    High: number;
  };
}

export interface RouteDetail {
  id: string;
  name: string;
  distance: number; // km
  duration: number; // mins
  path: [number, number][]; // coordinates
  riskScore: number; // 0-100
  riskLevel: 'Low' | 'Medium' | 'High';
  safetyFactor: string; // e.g. "92% Safe"
  accidentsEnRouteCount: number;
}

export interface RouteRecommendationResult {
  source: string;
  destination: string;
  routes: RouteDetail[];
  recommendationReason: string;
}

export interface DashboardStats {
  totalAccidents: number;
  totalFatal: number;
  totalSevere: number;
  totalMinor: number;
  totalCasualties: number;
  mostDangerousLocations: { name: string; count: number; fatalCount: number }[];
  severityStats: { name: string; value: number }[];
  causeStats: { name: string; value: number }[];
  vehicleStats: { name: string; value: number }[];
  weatherStats: { name: string; value: number }[];
  roadStats: { name: string; value: number }[];
  timeStats: { name: string; value: number }[];
  monthlyTrend: { name: string; count: number }[];
}
