import { useEffect, useRef } from 'react';
import { AccidentRecord } from '../types';
import { Hotspot } from '../db';

interface AccidentMapProps {
  records: AccidentRecord[];
  hotspots: Hotspot[];
  highlightHotspotId?: string;
  routes?: any[]; // RouteDetail[]
  centerCity?: string;
}

const CITY_COORDINATES: Record<string, [number, number]> = {
  Mumbai: [19.0760, 72.8777],
  Bangalore: [12.9716, 77.5946],
  Delhi: [28.6139, 77.2090],
  Hyderabad: [17.3850, 78.4867],
  Pune: [18.5204, 73.8567],
  Chennai: [13.0827, 80.2707],
  Kolkata: [22.5726, 88.3639],
  Jaipur: [26.9124, 75.7873],
  Lucknow: [26.8467, 80.9462],
  Ahmedabad: [23.0225, 72.5714],
  Guwahati: [26.1445, 91.7362],
  Kochi: [9.9312, 76.2673],
  Bhopal: [23.2599, 77.4126],
  Srinagar: [34.0837, 74.7973],
  Chandigarh: [30.7333, 76.7794],
  Patna: [25.5941, 85.1376],
  Bhubaneswar: [20.2961, 85.8245],
  Nagpur: [21.1458, 79.0882],
  Goa: [15.2993, 74.1240]
};

export default function AccidentMap({
  records,
  hotspots,
  highlightHotspotId,
  routes,
  centerCity
}: AccidentMapProps) {
  const mapContainerRef = useRef<HTMLDivElement>(null);
  const mapInstanceRef = useRef<any>(null);
  const layerGroupRef = useRef<any>(null);
  const routingLayerGroupRef = useRef<any>(null);

  useEffect(() => {
    const L = (window as any).L;
    if (!L || !mapContainerRef.current) return;

    // Initialize map if not already done
    if (!mapInstanceRef.current) {
      // Default center: India center
      mapInstanceRef.current = L.map(mapContainerRef.current, {
        center: [20.5937, 78.9629],
        zoom: 5,
        zoomControl: true,
      });

      // Sleek dark theme tile layer matching smart city dashboard
      L.tileLayer('https://{s}.basemaps.cartocdn.com/dark_all/{z}/{x}/{y}{r}.png', {
        attribution: '&copy; <a href="https://www.openstreetmap.org/copyright">OpenStreetMap</a> contributors &copy; <a href="https://carto.com/attributions">CARTO</a>',
        subdomains: 'abcd',
        maxZoom: 20
      }).addTo(mapInstanceRef.current);

      layerGroupRef.current = L.layerGroup().addTo(mapInstanceRef.current);
      routingLayerGroupRef.current = L.layerGroup().addTo(mapInstanceRef.current);
    }

    return () => {
      // We don't necessarily destroy the map container on every render to keep performance high
    };
  }, []);

  // Update map center based on selected city or routing
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !mapInstanceRef.current) return;

    if (centerCity && CITY_COORDINATES[centerCity]) {
      mapInstanceRef.current.setView(CITY_COORDINATES[centerCity], 12);
    } else {
      // Zoom out to show the whole country of India
      mapInstanceRef.current.setView([22.5937, 78.9629], 5);
    }
  }, [centerCity]);

  // Render markers, hotspots, and routes
  useEffect(() => {
    const L = (window as any).L;
    if (!L || !mapInstanceRef.current || !layerGroupRef.current || !routingLayerGroupRef.current) return;

    // Clear previous elements
    layerGroupRef.current.clearLayers();
    routingLayerGroupRef.current.clearLayers();

    // 1. Draw Hotspots (Clustered buffer zones)
    hotspots.forEach((hs) => {
      const isHighlighted = highlightHotspotId === hs.id;
      const radius = Math.max(100, hs.accidentCount * 30); // scale size
      const color = hs.riskLevel === 'High' ? '#f43f5e' : (hs.riskLevel === 'Medium' ? '#f59e0b' : '#eab308');
      
      const hotspotCircle = L.circle([hs.latitude, hs.longitude], {
        color: color,
        fillColor: color,
        fillOpacity: isHighlighted ? 0.6 : 0.25,
        weight: isHighlighted ? 4 : 2,
        radius: radius,
      });

      const popupContent = `
        <div style="color: #1e293b; font-family: sans-serif; font-size: 13px; line-height: 1.4;">
          <h4 style="margin: 0 0 4px 0; font-weight: 700; font-size: 14px; color: ${color};">
            ${hs.riskLevel.toUpperCase()} RISK HOTSPOT
          </h4>
          <strong>Location:</strong> ${hs.location}<br/>
          <strong>Accidents Count:</strong> ${hs.accidentCount}<br/>
          <strong>Fatalities:</strong> ${hs.fatalCount} lives lost
        </div>
      `;

      hotspotCircle.bindPopup(popupContent);
      layerGroupRef.current.addLayer(hotspotCircle);

      if (isHighlighted) {
        mapInstanceRef.current.setView([hs.latitude, hs.longitude], 14);
        setTimeout(() => hotspotCircle.openPopup(), 100);
      }
    });

    // 2. Draw individual accident markers if zoom is high or if hotspots are few
    records.forEach((rec) => {
      const color = rec.severityLevel === 'Fatal' ? '#ef4444' : (rec.severityLevel === 'Severe' ? '#f97316' : '#eab308');
      
      const accidentMarker = L.circleMarker([rec.latitude, rec.longitude], {
        radius: 5,
        fillColor: color,
        color: '#1e293b',
        weight: 1.5,
        opacity: 1,
        fillOpacity: 0.9
      });

      const popupContent = `
        <div style="color: #1e293b; font-family: sans-serif; font-size: 12px; line-height: 1.4; width: 180px;">
          <strong style="font-size: 13px; color: ${color}; display: block; border-bottom: 1px solid #e2e8f0; margin-bottom: 4px; padding-bottom: 2px;">
            ${rec.severityLevel} Accident
          </strong>
          <strong>ID:</strong> ${rec.accidentId}<br/>
          <strong>Location:</strong> ${rec.location}<br/>
          <strong>Date/Time:</strong> ${rec.date} ${rec.time}<br/>
          <strong>Cause:</strong> ${rec.accidentCause}<br/>
          <strong>Vehicle:</strong> ${rec.vehicleType}<br/>
          <strong>Casualties:</strong> ${rec.numberOfCasualties}
        </div>
      `;

      accidentMarker.bindPopup(popupContent);
      layerGroupRef.current.addLayer(accidentMarker);
    });

    // 3. Plot Safe Route recommendations if provided
    if (routes && routes.length > 0) {
      const routeBounds: any[] = [];
      
      routes.forEach((route, idx) => {
        const isRecommended = idx === 0; // First is the B-route bypass
        const color = isRecommended ? '#10b981' : '#ef4444'; // Green for safe, Red for risky
        const weight = isRecommended ? 6 : 4;
        const dashArray = isRecommended ? undefined : '10, 10';

        // Draw Polyline path
        const polyline = L.polyline(route.path, {
          color: color,
          weight: weight,
          opacity: 0.85,
          dashArray: dashArray
        });

        const popupContent = `
          <div style="color: #1e293b; font-family: sans-serif; font-size: 13px;">
            <strong style="color: ${color};">${route.name}</strong><br/>
            <strong>Distance:</strong> ${route.distance} km<br/>
            <strong>Est. Time:</strong> ${route.duration} mins<br/>
            <strong>Safety Score:</strong> <span style="font-weight:700; color: ${color}">${route.safetyFactor}</span><br/>
            <strong>Historical Accidents:</strong> ${route.accidentsEnRouteCount}
          </div>
        `;
        polyline.bindPopup(popupContent);
        routingLayerGroupRef.current.addLayer(polyline);

        route.path.forEach((p: any) => routeBounds.push(p));

        // Start & End points custom labels
        if (idx === 0) {
          const startCoords = route.path[0];
          const endCoords = route.path[route.path.length - 1];

          const startMarker = L.circleMarker(startCoords, {
            radius: 8,
            fillColor: '#6366f1',
            color: '#ffffff',
            weight: 2,
            fillOpacity: 1
          }).bindPopup('<strong style="color:#6366f1">SOURCE START</strong>');

          const endMarker = L.circleMarker(endCoords, {
            radius: 8,
            fillColor: '#ec4899',
            color: '#ffffff',
            weight: 2,
            fillOpacity: 1
          }).bindPopup('<strong style="color:#ec4899">DESTINATION END</strong>');

          routingLayerGroupRef.current.addLayer(startMarker);
          routingLayerGroupRef.current.addLayer(endMarker);
        }
      });

      // Autoscale view to perfectly enclose the routes
      if (routeBounds.length > 0) {
        mapInstanceRef.current.fitBounds(routeBounds, { padding: [50, 50] });
      }
    }
  }, [records, hotspots, highlightHotspotId, routes]);

  return (
    <div className="relative w-full h-full min-h-[350px] md:min-h-[450px]">
      <div 
        ref={mapContainerRef} 
        id="leaflet-smart-city-map" 
        className="w-full h-full rounded-xl border border-slate-800 shadow-2xl z-0"
      />
      
      {/* Absolute Map Legend */}
      <div className="absolute bottom-4 right-4 bg-slate-900/95 border border-slate-800 text-slate-300 p-3 rounded-lg shadow-lg z-10 text-xs flex flex-col gap-1.5 backdrop-blur-md">
        <div className="font-semibold text-slate-100 border-b border-slate-800 pb-1 mb-1 font-display">Risk Map Legend</div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-rose-500 block"></span>
          <span>High Risk Zone (&ge;8 Incidents / Fatalities)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-amber-500 block"></span>
          <span>Medium Risk Zone (4-7 Incidents)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="w-3 h-3 rounded-full bg-yellow-500 block"></span>
          <span>Low Risk Zone (&lt;4 Incidents)</span>
        </div>
        <div className="flex items-center gap-2 pt-1 border-t border-slate-800/50 mt-1">
          <span className="h-0.5 w-5 bg-emerald-500 block"></span>
          <span>Recommended Route (Safe)</span>
        </div>
        <div className="flex items-center gap-2">
          <span className="h-0.5 w-5 bg-rose-500 border-dashed border-t border-rose-500 block"></span>
          <span>Risky Direct Route (Avoid)</span>
        </div>
      </div>
    </div>
  );
}
