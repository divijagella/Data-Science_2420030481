import { AccidentRecord, DashboardStats, PredictionInput, PredictionResult, RouteDetail, RouteRecommendationResult } from './types';
import { predictAccidentRisk, retrainMLModels } from './ml';

// Helpers to generate coordinates around city centers
const CITIES_COORDINATES: Record<string, { lat: number; lng: number }> = {
  Mumbai: { lat: 19.0760, lng: 72.8777 },
  Bangalore: { lat: 12.9716, lng: 77.5946 },
  Delhi: { lat: 28.6139, lng: 77.2090 },
  Hyderabad: { lat: 17.3850, lng: 78.4867 },
  Pune: { lat: 18.5204, lng: 73.8567 },
  Chennai: { lat: 13.0827, lng: 80.2707 },
  Kolkata: { lat: 22.5726, lng: 88.3639 },
  Jaipur: { lat: 26.9124, lng: 75.7873 },
  Lucknow: { lat: 26.8467, lng: 80.9462 },
  Ahmedabad: { lat: 23.0225, lng: 72.5714 },
  Guwahati: { lat: 26.1445, lng: 91.7362 },
  Kochi: { lat: 9.9312, lng: 76.2673 },
  Bhopal: { lat: 23.2599, lng: 77.4126 },
  Srinagar: { lat: 34.0837, lng: 74.7973 },
  Chandigarh: { lat: 30.7333, lng: 76.7794 },
  Patna: { lat: 25.5941, lng: 85.1376 },
  Bhubaneswar: { lat: 20.2961, lng: 85.8245 },
  Nagpur: { lat: 21.1458, lng: 79.0882 },
  Goa: { lat: 15.2993, lng: 74.1240 }
};

// Seed 60+ realistic Indian traffic accidents
const INITIAL_ACCIDENTS: AccidentRecord[] = [
  // Bangalore
  {
    accidentId: "IND-BLR-001",
    date: "2026-01-15",
    time: "18:45",
    location: "Silk Board Junction, Bangalore",
    latitude: 12.9176,
    longitude: 77.6244,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-002",
    date: "2026-01-20",
    time: "08:30",
    location: "Silk Board Junction, Bangalore",
    latitude: 12.9180,
    longitude: 77.6250,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-003",
    date: "2026-02-02",
    time: "20:15",
    location: "Silk Board Junction, Bangalore",
    latitude: 12.9172,
    longitude: 77.6240,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 4,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-004",
    date: "2026-02-14",
    time: "23:50",
    location: "Outer Ring Road (Bellandur), Bangalore",
    latitude: 12.9279,
    longitude: 77.6801,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-BLR-005",
    date: "2026-02-18",
    time: "19:00",
    location: "Outer Ring Road (Bellandur), Bangalore",
    latitude: 12.9285,
    longitude: 77.6812,
    weatherCondition: "Rain",
    roadCondition: "Potholes",
    vehicleType: "Car",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-006",
    date: "2026-03-01",
    time: "15:20",
    location: "Outer Ring Road (Bellandur), Bangalore",
    latitude: 12.9272,
    longitude: 77.6795,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BLR-007",
    date: "2026-03-10",
    time: "21:30",
    location: "Marathahalli Bridge, Bangalore",
    latitude: 12.9562,
    longitude: 77.7011,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Truck",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 3,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BLR-008",
    date: "2026-03-15",
    time: "07:45",
    location: "Marathahalli Bridge, Bangalore",
    latitude: 12.9568,
    longitude: 77.7019,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-009",
    date: "2026-03-20",
    time: "11:15",
    location: "Electronic City Flyover, Bangalore",
    latitude: 12.8501,
    longitude: 77.6590,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BLR-010",
    date: "2026-04-05",
    time: "14:30",
    location: "Hebbal Flyover, Bangalore",
    latitude: 13.0359,
    longitude: 77.5978,
    weatherCondition: "Cloudy",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BLR-011",
    date: "2026-04-12",
    time: "22:15",
    location: "Hebbal Flyover, Bangalore",
    latitude: 13.0365,
    longitude: 77.5985,
    weatherCondition: "Rain",
    roadCondition: "Potholes",
    vehicleType: "Two-Wheeler",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },

  // Mumbai
  {
    accidentId: "IND-BOM-001",
    date: "2026-01-10",
    time: "19:30",
    location: "Western Express Highway, Mumbai",
    latitude: 19.1156,
    longitude: 72.8560,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BOM-002",
    date: "2026-01-12",
    time: "23:45",
    location: "Western Express Highway, Mumbai",
    latitude: 19.1160,
    longitude: 72.8565,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-BOM-003",
    date: "2026-01-28",
    time: "08:15",
    location: "Western Express Highway, Mumbai",
    latitude: 19.1150,
    longitude: 72.8552,
    weatherCondition: "Mist",
    roadCondition: "Dry",
    vehicleType: "Bus",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 3,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BOM-004",
    date: "2026-02-05",
    time: "17:10",
    location: "Sion Circle, Mumbai",
    latitude: 19.0368,
    longitude: 72.8612,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BOM-005",
    date: "2026-02-22",
    time: "14:20",
    location: "Sion Circle, Mumbai",
    latitude: 19.0372,
    longitude: 72.8620,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BOM-006",
    date: "2026-03-03",
    time: "20:45",
    location: "Saki Naka Junction, Mumbai",
    latitude: 19.0962,
    longitude: 72.8877,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BOM-007",
    date: "2026-03-12",
    time: "10:30",
    location: "Saki Naka Junction, Mumbai",
    latitude: 19.0968,
    longitude: 72.8885,
    weatherCondition: "Cloudy",
    roadCondition: "Potholes",
    vehicleType: "Truck",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BOM-008",
    date: "2026-04-02",
    time: "22:00",
    location: "Eastern Express Highway, Mumbai",
    latitude: 19.1678,
    longitude: 72.9401,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BOM-009",
    date: "2026-04-18",
    time: "13:40",
    location: "Dharavi T-Junction, Mumbai",
    latitude: 19.0433,
    longitude: 72.8510,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },

  // Delhi
  {
    accidentId: "IND-DEL-001",
    date: "2026-01-08",
    time: "07:30",
    location: "Dhaula Kuan Chowk, Delhi",
    latitude: 28.5918,
    longitude: 77.1612,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Bus",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 5,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-DEL-002",
    date: "2026-01-18",
    time: "23:15",
    location: "Dhaula Kuan Chowk, Delhi",
    latitude: 28.5922,
    longitude: 77.1620,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Truck",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 3,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-DEL-003",
    date: "2026-02-01",
    time: "09:00",
    location: "Dhaula Kuan Chowk, Delhi",
    latitude: 28.5910,
    longitude: 77.1605,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-DEL-004",
    date: "2026-02-12",
    time: "20:30",
    location: "Ring Road (AIIMS), Delhi",
    latitude: 28.5672,
    longitude: 77.2100,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-DEL-005",
    date: "2026-02-28",
    time: "15:45",
    location: "Ring Road (AIIMS), Delhi",
    latitude: 28.5678,
    longitude: 77.2112,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-DEL-006",
    date: "2026-03-05",
    time: "22:45",
    location: "Rao Tula Ram Marg, Delhi",
    latitude: 28.5721,
    longitude: 77.1652,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-DEL-007",
    date: "2026-03-22",
    time: "18:20",
    location: "Mukarba Chowk, Delhi",
    latitude: 28.7369,
    longitude: 77.1592,
    weatherCondition: "Cloudy",
    roadCondition: "Under Construction",
    vehicleType: "Truck",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 3,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-DEL-008",
    date: "2026-04-10",
    time: "08:45",
    location: "ITO Crossing, Delhi",
    latitude: 28.6282,
    longitude: 77.2410,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },

  // Hyderabad
  {
    accidentId: "IND-HYD-001",
    date: "2026-01-11",
    time: "21:15",
    location: "Gachibowli Circle, Hyderabad",
    latitude: 17.4428,
    longitude: 78.3489,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-HYD-002",
    date: "2026-01-25",
    time: "19:40",
    location: "Gachibowli Circle, Hyderabad",
    latitude: 17.4432,
    longitude: 78.3495,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-HYD-003",
    date: "2026-02-15",
    time: "10:30",
    location: "Hitec City Junction, Hyderabad",
    latitude: 17.4483,
    longitude: 78.3741,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-HYD-004",
    date: "2026-03-08",
    time: "23:30",
    location: "Begumpet Flyover, Hyderabad",
    latitude: 17.4375,
    longitude: 78.4601,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-HYD-005",
    date: "2026-03-25",
    time: "13:10",
    location: "Charminar Main Road, Hyderabad",
    latitude: 17.3616,
    longitude: 78.4747,
    weatherCondition: "Clear",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Traffic Violation",
    severityLevel: "Severe",
    numberOfCasualties: 4,
    trafficDensity: "High"
  },

  // Pune
  {
    accidentId: "IND-PUN-001",
    date: "2026-01-22",
    time: "19:15",
    location: "Katraj Chowk, Pune",
    latitude: 18.4529,
    longitude: 73.8549,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Truck",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 3,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-PUN-002",
    date: "2026-02-10",
    time: "22:50",
    location: "Katraj Chowk, Pune",
    latitude: 18.4535,
    longitude: 73.8555,
    weatherCondition: "Mist",
    roadCondition: "Potholes",
    vehicleType: "Two-Wheeler",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-PUN-003",
    date: "2026-02-20",
    time: "09:30",
    location: "Wakad Bridge, Pune",
    latitude: 18.5982,
    longitude: 73.7681,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-PUN-004",
    date: "2026-03-14",
    time: "18:10",
    location: "Swargate Chowk, Pune",
    latitude: 18.5018,
    longitude: 73.8569,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-PUN-005",
    date: "2026-03-29",
    time: "15:30",
    location: "Hinjewadi Phase 1 Circle, Pune",
    latitude: 18.5912,
    longitude: 73.7391,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-PUN-006",
    date: "2026-04-05",
    time: "23:40",
    location: "Senapati Bapat Road, Pune",
    latitude: 18.5308,
    longitude: 73.8290,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },
  // Chennai
  {
    accidentId: "IND-MAA-001",
    date: "2026-01-14",
    time: "18:20",
    location: "Mount Road Corridor, Chennai",
    latitude: 13.0612,
    longitude: 80.2520,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-MAA-002",
    date: "2026-02-18",
    time: "08:15",
    location: "Kathipara Junction, Chennai",
    latitude: 13.0084,
    longitude: 80.2032,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-MAA-003",
    date: "2026-03-24",
    time: "22:10",
    location: "Mount Road Corridor, Chennai",
    latitude: 13.0618,
    longitude: 80.2530,
    weatherCondition: "Clear",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 3,
    trafficDensity: "Medium"
  },
  // Kolkata
  {
    accidentId: "IND-CCU-001",
    date: "2026-01-18",
    time: "14:15",
    location: "Howrah Bridge Chowk, Kolkata",
    latitude: 22.5852,
    longitude: 88.3524,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-CCU-002",
    date: "2026-02-22",
    time: "21:30",
    location: "Howrah Bridge Chowk, Kolkata",
    latitude: 22.5858,
    longitude: 88.3530,
    weatherCondition: "Rain",
    roadCondition: "Potholes",
    vehicleType: "Truck",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-CCU-003",
    date: "2026-03-05",
    time: "19:45",
    location: "Park Street Crossing, Kolkata",
    latitude: 22.5482,
    longitude: 88.3539,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  // Jaipur
  {
    accidentId: "IND-JAI-001",
    date: "2026-01-20",
    time: "09:30",
    location: "Ajmeri Gate Crossing, Jaipur",
    latitude: 26.9150,
    longitude: 75.8120,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-JAI-002",
    date: "2026-02-15",
    time: "23:00",
    location: "Sindhi Camp Bus Stand, Jaipur",
    latitude: 26.9242,
    longitude: 75.8015,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Bus",
    accidentCause: "Distracted Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-JAI-003",
    date: "2026-03-12",
    time: "08:15",
    location: "Ajmeri Gate Crossing, Jaipur",
    latitude: 26.9155,
    longitude: 75.8125,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Lucknow
  {
    accidentId: "IND-LKO-001",
    date: "2026-01-22",
    time: "11:30",
    location: "Hazratganj Intersection, Lucknow",
    latitude: 26.8512,
    longitude: 80.9430,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Distracted Driving",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-LKO-002",
    date: "2026-02-10",
    time: "22:45",
    location: "Hazratganj Intersection, Lucknow",
    latitude: 26.8516,
    longitude: 80.9435,
    weatherCondition: "Clear",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-LKO-003",
    date: "2026-03-18",
    time: "08:45",
    location: "Charbagh Station Circle, Lucknow",
    latitude: 26.8282,
    longitude: 80.9215,
    weatherCondition: "Fog",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  // Ahmedabad
  {
    accidentId: "IND-AMD-001",
    date: "2026-01-25",
    time: "23:50",
    location: "Sarkhej-Gandhinagar Highway, Ahmedabad",
    latitude: 23.0322,
    longitude: 72.5012,
    weatherCondition: "Mist",
    roadCondition: "Dry",
    vehicleType: "Truck",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 3,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-AMD-002",
    date: "2026-02-28",
    time: "18:30",
    location: "Sarkhej-Gandhinagar Highway, Ahmedabad",
    latitude: 23.0328,
    longitude: 72.5018,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-AMD-003",
    date: "2026-03-15",
    time: "09:15",
    location: "Nehru Bridge Crossing, Ahmedabad",
    latitude: 23.0298,
    longitude: 72.5742,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Guwahati
  {
    accidentId: "IND-GAU-001",
    date: "2026-01-30",
    time: "19:15",
    location: "GS Road Corridor, Guwahati",
    latitude: 26.1524,
    longitude: 91.7612,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-GAU-002",
    date: "2026-02-18",
    time: "21:40",
    location: "GS Road Corridor, Guwahati",
    latitude: 26.1530,
    longitude: 91.7618,
    weatherCondition: "Rain",
    roadCondition: "Potholes",
    vehicleType: "Two-Wheeler",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-GAU-003",
    date: "2026-03-22",
    time: "07:30",
    location: "Jalukbari Bypass, Guwahati",
    latitude: 26.1415,
    longitude: 91.6812,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Truck",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  // Kochi
  {
    accidentId: "IND-COK-001",
    date: "2026-01-28",
    time: "22:15",
    location: "Vytilla Junction, Kochi",
    latitude: 9.9624,
    longitude: 76.3190,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-COK-002",
    date: "2026-02-14",
    time: "15:30",
    location: "Vytilla Junction, Kochi",
    latitude: 9.9630,
    longitude: 76.3195,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-COK-003",
    date: "2026-03-08",
    time: "11:45",
    location: "MG Road Crossing, Kochi",
    latitude: 9.9712,
    longitude: 76.2812,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Bhopal
  {
    accidentId: "IND-BHO-001",
    date: "2026-01-12",
    time: "18:40",
    location: "Hamidia Road Intersection, Bhopal",
    latitude: 23.2652,
    longitude: 77.4112,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BHO-002",
    date: "2026-02-20",
    time: "23:15",
    location: "Hamidia Road Intersection, Bhopal",
    latitude: 23.2658,
    longitude: 77.4118,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Drunk Driving",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-BHO-003",
    date: "2026-03-11",
    time: "12:30",
    location: "Cheetah Bridge Crossing, Bhopal",
    latitude: 23.2422,
    longitude: 77.4312,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  // Srinagar
  {
    accidentId: "IND-SXR-001",
    date: "2026-01-15",
    time: "08:30",
    location: "Lal Chowk Square, Srinagar",
    latitude: 34.0852,
    longitude: 74.8012,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-SXR-002",
    date: "2026-02-12",
    time: "22:15",
    location: "Lal Chowk Square, Srinagar",
    latitude: 34.0858,
    longitude: 74.8018,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Low"
  },
  {
    accidentId: "IND-SXR-003",
    date: "2026-03-25",
    time: "14:10",
    location: "Dal Lake Boulevard, Srinagar",
    latitude: 34.0922,
    longitude: 74.8250,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Chandigarh
  {
    accidentId: "IND-IXC-001",
    date: "2026-01-29",
    time: "21:50",
    location: "Tribune Chowk, Chandigarh",
    latitude: 30.7122,
    longitude: 76.8012,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-IXC-002",
    date: "2026-02-17",
    time: "07:45",
    location: "Tribune Chowk, Chandigarh",
    latitude: 30.7128,
    longitude: 76.8018,
    weatherCondition: "Fog",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Distracted Driving",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-IXC-003",
    date: "2026-03-10",
    time: "11:30",
    location: "Sector 17 Bus Stand, Chandigarh",
    latitude: 30.7412,
    longitude: 76.7780,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Bus",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Patna
  {
    accidentId: "IND-PAT-001",
    date: "2026-01-21",
    time: "09:15",
    location: "Gandhi Maidan Road, Patna",
    latitude: 25.6182,
    longitude: 85.1412,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Bus",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 3,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-PAT-002",
    date: "2026-02-14",
    time: "18:40",
    location: "Gandhi Maidan Road, Patna",
    latitude: 25.6188,
    longitude: 85.1418,
    weatherCondition: "Clear",
    roadCondition: "Potholes",
    vehicleType: "Two-Wheeler",
    accidentCause: "Poor Road Conditions",
    severityLevel: "Severe",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-PAT-003",
    date: "2026-03-09",
    time: "15:10",
    location: "Dak Bunglow Crossing, Patna",
    latitude: 25.6082,
    longitude: 85.1315,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Auto-Rickshaw",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  // Bhubaneswar
  {
    accidentId: "IND-BBI-001",
    date: "2026-01-16",
    time: "20:45",
    location: "Vani Vihar Crossing, Bhubaneswar",
    latitude: 20.2922,
    longitude: 85.8412,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Truck",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 2,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-BBI-002",
    date: "2026-02-25",
    time: "08:15",
    location: "Vani Vihar Crossing, Bhubaneswar",
    latitude: 20.2928,
    longitude: 85.8418,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Traffic Violation",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-BBI-003",
    date: "2026-03-12",
    time: "16:30",
    location: "Jayadev Vihar Junction, Bhubaneswar",
    latitude: 20.3012,
    longitude: 85.8215,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  },
  // Nagpur
  {
    accidentId: "IND-NAG-001",
    date: "2026-01-10",
    time: "13:20",
    location: "Zero Mile Intersection, Nagpur",
    latitude: 21.1512,
    longitude: 79.0812,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Distracted Driving",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-NAG-002",
    date: "2026-02-18",
    time: "22:10",
    location: "Zero Mile Intersection, Nagpur",
    latitude: 21.1518,
    longitude: 79.0818,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-NAG-003",
    date: "2026-03-29",
    time: "10:15",
    location: "Sitabuldi Interchange, Nagpur",
    latitude: 21.1415,
    longitude: 79.0715,
    weatherCondition: "Clear",
    roadCondition: "Wet",
    vehicleType: "Bus",
    accidentCause: "Traffic Violation",
    severityLevel: "Minor",
    numberOfCasualties: 2,
    trafficDensity: "High"
  },
  // Goa
  {
    accidentId: "IND-GOA-001",
    date: "2026-01-20",
    time: "19:50",
    location: "Panaji Kadamba Bus Stand, Goa",
    latitude: 15.4952,
    longitude: 73.8312,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Two-Wheeler",
    accidentCause: "Overspeeding",
    severityLevel: "Fatal",
    numberOfCasualties: 1,
    trafficDensity: "High"
  },
  {
    accidentId: "IND-GOA-002",
    date: "2026-02-14",
    time: "21:30",
    location: "Panaji Kadamba Bus Stand, Goa",
    latitude: 15.4958,
    longitude: 73.8318,
    weatherCondition: "Rain",
    roadCondition: "Wet",
    vehicleType: "Car",
    accidentCause: "Traffic Violation",
    severityLevel: "Severe",
    numberOfCasualties: 1,
    trafficDensity: "Medium"
  },
  {
    accidentId: "IND-GOA-003",
    date: "2026-03-19",
    time: "14:20",
    location: "Margao Railway Road, Goa",
    latitude: 15.2715,
    longitude: 73.9612,
    weatherCondition: "Clear",
    roadCondition: "Dry",
    vehicleType: "Car",
    accidentCause: "Distracted Driving",
    severityLevel: "Minor",
    numberOfCasualties: 0,
    trafficDensity: "High"
  }
];

// In-Memory Database store
let accidentsDb: AccidentRecord[] = [...INITIAL_ACCIDENTS];

// Retrieve all accidents
export function getAllAccidents(): AccidentRecord[] {
  return accidentsDb;
}

// Set full accidents database (e.g. from uploaded CSV)
export function setAllAccidents(records: AccidentRecord[]) {
  accidentsDb = records;
  // Retrain ML models based on the new records
  retrainMLModels(accidentsDb);
}

// Reset database back to seed values
export function resetDatabase() {
  accidentsDb = [...INITIAL_ACCIDENTS];
  retrainMLModels(accidentsDb);
}

// Add a single accident record
export function addAccidentRecord(record: AccidentRecord) {
  accidentsDb.push(record);
  retrainMLModels(accidentsDb);
}

// Helper to parse line while keeping commas inside quotes intact
export function parseCSVLine(line: string): string[] {
  const result: string[] = [];
  let current = '';
  let inQuotes = false;
  
  for (let i = 0; i < line.length; i++) {
    const char = line[i];
    if (char === '"') {
      inQuotes = !inQuotes;
    } else if (char === ',' && !inQuotes) {
      result.push(current.trim());
      current = '';
    } else {
      current += char;
    }
  }
  result.push(current.trim());
  return result;
}

// Parse uploaded CSV content into AccidentRecord objects
export function parseCSV(csvContent: string): { successCount: number; errors: string[]; parsed: AccidentRecord[] } {
  const errors: string[] = [];
  const parsed: AccidentRecord[] = [];
  
  const lines = csvContent.split(/\r?\n/);
  if (lines.length < 2) {
    return { successCount: 0, errors: ["Empty CSV or missing header row"], parsed };
  }

  // Find header mappings
  const headers = parseCSVLine(lines[0]).map(h => h.toLowerCase().replace(/[\s_]/g, ''));
  
  const idIdx = headers.findIndex(h => h.includes('id'));
  const dateIdx = headers.findIndex(h => h.includes('date'));
  const timeIdx = headers.findIndex(h => h.includes('time'));
  const locIdx = headers.findIndex(h => h.includes('location'));
  const latIdx = headers.findIndex(h => h.includes('lat'));
  const lngIdx = headers.findIndex(h => h.includes('lng') || h.includes('lon'));
  const weatherIdx = headers.findIndex(h => h.includes('weather'));
  const roadIdx = headers.findIndex(h => h.includes('road'));
  const vehicleIdx = headers.findIndex(h => h.includes('vehicle'));
  const causeIdx = headers.findIndex(h => h.includes('cause'));
  const severityIdx = headers.findIndex(h => h.includes('severity'));
  const casualtyIdx = headers.findIndex(h => h.includes('casualty') || h.includes('casualties'));

  for (let i = 1; i < lines.length; i++) {
    const line = lines[i];
    if (!line.trim()) continue;

    const values = parseCSVLine(line);
    if (values.length < 5) {
      errors.push(`Row ${i + 1}: Insufficient column values.`);
      continue;
    }

    try {
      const accidentId = idIdx !== -1 && values[idIdx] ? values[idIdx] : `CSV-ROW-${i + 1}`;
      const date = dateIdx !== -1 && values[dateIdx] ? values[dateIdx] : new Date().toISOString().split('T')[0];
      const time = timeIdx !== -1 && values[timeIdx] ? values[timeIdx] : "12:00";
      const location = locIdx !== -1 && values[locIdx] ? values[locIdx] : "Unknown Junction";
      
      const lat = latIdx !== -1 && !isNaN(parseFloat(values[latIdx])) ? parseFloat(values[latIdx]) : (12.9716 + (Math.random() - 0.5) * 0.1);
      const lng = lngIdx !== -1 && !isNaN(parseFloat(values[lngIdx])) ? parseFloat(values[lngIdx]) : (77.5946 + (Math.random() - 0.5) * 0.1);
      
      let weatherCondition = (weatherIdx !== -1 && values[weatherIdx] ? values[weatherIdx] : 'Clear') as any;
      if (!['Clear', 'Rain', 'Fog', 'Cloudy', 'Mist'].includes(weatherCondition)) {
        weatherCondition = 'Clear';
      }

      let roadCondition = (roadIdx !== -1 && values[roadIdx] ? values[roadIdx] : 'Dry') as any;
      if (!['Dry', 'Wet', 'Potholes', 'Under Construction', 'Sandy'].includes(roadCondition)) {
        roadCondition = 'Dry';
      }

      let vehicleType = (vehicleIdx !== -1 && values[vehicleIdx] ? values[vehicleIdx] : 'Car') as any;
      if (!['Two-Wheeler', 'Car', 'Truck', 'Bus', 'Auto-Rickshaw'].includes(vehicleType)) {
        vehicleType = 'Car';
      }

      let accidentCause = (causeIdx !== -1 && values[causeIdx] ? values[causeIdx] : 'Overspeeding') as any;
      if (!['Overspeeding', 'Drunk Driving', 'Traffic Violation', 'Poor Road Conditions', 'Distracted Driving'].includes(accidentCause)) {
        accidentCause = 'Overspeeding';
      }

      let severityLevel = (severityIdx !== -1 && values[severityIdx] ? values[severityIdx] : 'Minor') as any;
      // Capitalize first letter
      severityLevel = severityLevel.charAt(0).toUpperCase() + severityLevel.slice(1).toLowerCase();
      if (!['Fatal', 'Severe', 'Minor'].includes(severityLevel)) {
        severityLevel = 'Minor';
      }

      const numberOfCasualties = casualtyIdx !== -1 && !isNaN(parseInt(values[casualtyIdx], 10)) ? parseInt(values[casualtyIdx], 10) : 0;

      parsed.push({
        accidentId,
        date,
        time,
        location,
        latitude: lat,
        longitude: lng,
        weatherCondition,
        roadCondition,
        vehicleType,
        accidentCause,
        severityLevel,
        numberOfCasualties,
        trafficDensity: severityLevel === 'Fatal' ? 'High' : (severityLevel === 'Severe' ? 'Medium' : 'Low')
      });
    } catch (e: any) {
      errors.push(`Row ${i + 1}: Parse error - ${e.message}`);
    }
  }

  return {
    successCount: parsed.length,
    errors,
    parsed
  };
}

// DBSCAN-like simple distance coordinate clustering for hotspot detection
export interface Hotspot {
  id: string;
  location: string;
  latitude: number;
  longitude: number;
  accidentCount: number;
  fatalCount: number;
  riskLevel: 'Low' | 'Medium' | 'High';
  accidentIds: string[];
}

export function detectHotspots(records: AccidentRecord[]): Hotspot[] {
  const hotspots: Hotspot[] = [];
  const visited = new Set<string>();

  // EPS distance in degrees (~1.5 km threshold for traffic density clusters)
  const EPS = 0.015;

  records.forEach((r) => {
    if (visited.has(r.accidentId)) return;

    // Find nearby accidents
    const cluster = records.filter(other => {
      const latDiff = other.latitude - r.latitude;
      const lngDiff = other.longitude - r.longitude;
      const dist = Math.sqrt(latDiff * latDiff + lngDiff * lngDiff);
      return dist <= EPS;
    });

    if (cluster.length >= 2) {
      cluster.forEach(c => visited.add(c.accidentId));
      
      const fatalCount = cluster.filter(c => c.severityLevel === 'Fatal').length;
      const severeCount = cluster.filter(c => c.severityLevel === 'Severe').length;
      
      let riskLevel: 'Low' | 'Medium' | 'High' = 'Low';
      if (cluster.length >= 8 || fatalCount >= 2) {
        riskLevel = 'High';
      } else if (cluster.length >= 4 || severeCount >= 1) {
        riskLevel = 'Medium';
      }

      // Group location names
      const locCounts: Record<string, number> = {};
      cluster.forEach(c => {
        locCounts[c.location] = (locCounts[c.location] || 0) + 1;
      });
      const topLocation = Object.entries(locCounts).sort((a, b) => b[1] - a[1])[0]?.[0] || r.location;

      // Centroid latitude/longitude
      const avgLat = cluster.reduce((sum, c) => sum + c.latitude, 0) / cluster.length;
      const avgLng = cluster.reduce((sum, c) => sum + c.longitude, 0) / cluster.length;

      hotspots.push({
        id: `HOTSPOT-${r.accidentId}`,
        location: topLocation,
        latitude: avgLat,
        longitude: avgLng,
        accidentCount: cluster.length,
        fatalCount,
        riskLevel,
        accidentIds: cluster.map(c => c.accidentId)
      });
    }
  });

  return hotspots;
}

// Calculate statistical breakdown for the dashboard
export function getDashboardStats(records: AccidentRecord[]): DashboardStats {
  const totalAccidents = records.length;
  const totalFatal = records.filter(r => r.severityLevel === 'Fatal').length;
  const totalSevere = records.filter(r => r.severityLevel === 'Severe').length;
  const totalMinor = records.filter(r => r.severityLevel === 'Minor').length;
  const totalCasualties = records.reduce((sum, r) => sum + r.numberOfCasualties, 0);

  // Dangerous locations mapping
  const locMap: Record<string, { count: number; fatal: number }> = {};
  records.forEach(r => {
    // Standardize key to match nearby junctions
    let key = r.location;
    const parts = key.split(',');
    if (parts.length > 0) {
      key = parts[0].trim(); // Use junction name primarily
    }
    if (!locMap[key]) {
      locMap[key] = { count: 0, fatal: 0 };
    }
    locMap[key].count++;
    if (r.severityLevel === 'Fatal') {
      locMap[key].fatal++;
    }
  });

  const mostDangerousLocations = Object.entries(locMap)
    .map(([name, val]) => ({ name, count: val.count, fatalCount: val.fatal }))
    .sort((a, b) => b.count - a.count)
    .slice(0, 5);

  // Severity stats
  const severityStats = [
    { name: 'Fatal', value: totalFatal },
    { name: 'Severe Injury', value: totalSevere },
    { name: 'Minor/Property Damage', value: totalMinor }
  ];

  // Cause stats
  const causeCounts: Record<string, number> = {};
  records.forEach(r => {
    causeCounts[r.accidentCause] = (causeCounts[r.accidentCause] || 0) + 1;
  });
  const causeStats = Object.entries(causeCounts).map(([name, value]) => ({ name, value }));

  // Vehicle stats
  const vehicleCounts: Record<string, number> = {};
  records.forEach(r => {
    vehicleCounts[r.vehicleType] = (vehicleCounts[r.vehicleType] || 0) + 1;
  });
  const vehicleStats = Object.entries(vehicleCounts).map(([name, value]) => ({ name, value }));

  // Weather stats
  const weatherCounts: Record<string, number> = {};
  records.forEach(r => {
    weatherCounts[r.weatherCondition] = (weatherCounts[r.weatherCondition] || 0) + 1;
  });
  const weatherStats = Object.entries(weatherCounts).map(([name, value]) => ({ name, value }));

  // Road stats
  const roadCounts: Record<string, number> = {};
  records.forEach(r => {
    roadCounts[r.roadCondition] = (roadCounts[r.roadCondition] || 0) + 1;
  });
  const roadStats = Object.entries(roadCounts).map(([name, value]) => ({ name, value }));

  // Time-of-day stats
  const timeCounts = { Morning: 0, Afternoon: 0, Evening: 0, Night: 0 };
  records.forEach(r => {
    const timeOfDay = r.time ? getTimeOfDay(r.time) : 'Afternoon';
    timeCounts[timeOfDay]++;
  });
  const timeStats = Object.entries(timeCounts).map(([name, value]) => ({ name, value }));

  // Monthly trends (seed data mostly in Jan, Feb, Mar, Apr 2026)
  const monthNames = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
  const monthCounts: Record<string, number> = {};
  monthNames.forEach(m => { monthCounts[m] = 0; });

  records.forEach(r => {
    if (!r.date) return;
    const parts = r.date.split('-');
    const mIdx = parseInt(parts[1], 10) - 1;
    if (!isNaN(mIdx) && mIdx >= 0 && mIdx < 12) {
      monthCounts[monthNames[mIdx]]++;
    }
  });

  const monthlyTrend = monthNames.map(name => ({ name, count: monthCounts[name] }));

  return {
    totalAccidents,
    totalFatal,
    totalSevere,
    totalMinor,
    totalCasualties,
    mostDangerousLocations,
    severityStats,
    causeStats,
    vehicleStats,
    weatherStats,
    roadStats,
    timeStats,
    monthlyTrend
  };
}

// Helper to calculate Time Of Day index
function getTimeOfDay(timeStr: string): 'Morning' | 'Afternoon' | 'Evening' | 'Night' {
  if (!timeStr) return 'Afternoon';
  const hour = parseInt(timeStr.split(':')[0], 10);
  if (isNaN(hour)) return 'Afternoon';
  if (hour >= 5 && hour < 12) return 'Morning';
  if (hour >= 12 && hour < 17) return 'Afternoon';
  if (hour >= 17 && hour < 21) return 'Evening';
  return 'Night';
}

// Calculate distance between two coordinates in km
function calculateHaversineDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
  const R = 6371; // radius of Earth in km
  const dLat = ((lat2 - lat1) * Math.PI) / 180;
  const dLon = ((lon2 - lon1) * Math.PI) / 180;
  const a =
    Math.sin(dLat / 2) * Math.sin(dLat / 2) +
    Math.cos((lat1 * Math.PI) / 180) *
      Math.cos((lat2 * Math.PI) / 180) *
      Math.sin(dLon / 2) *
      Math.sin(dLon / 2);
  const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
  return R * c;
}

// Generate Safe Route recommendation simulation based on current database
export function recommendSafeRoutes(source: string, destination: string, records: AccidentRecord[]): RouteRecommendationResult {
  // Let's identify the cities of source and destination
  let cityCenter = CITIES_COORDINATES.Bangalore; // default
  let cityName = 'Bangalore';

  for (const [name, coords] of Object.entries(CITIES_COORDINATES)) {
    if (source.toLowerCase().includes(name.toLowerCase()) || destination.toLowerCase().includes(name.toLowerCase())) {
      cityCenter = coords;
      cityName = name;
      break;
    }
  }

  // Create route details. Let's create two simulated paths: Route A (direct, high risk) and Route B (alternative, low risk)
  // Let's base the simulation coordinates on cityCenter
  const latOffset = (Math.random() - 0.5) * 0.05;
  const lngOffset = (Math.random() - 0.5) * 0.05;

  const startLat = cityCenter.lat + latOffset;
  const startLng = cityCenter.lng + lngOffset;
  const endLat = cityCenter.lat - latOffset;
  const endLng = cityCenter.lng - lngOffset;

  // Find accidents close to the direct line between start and end coordinates
  const midpointLat = (startLat + endLat) / 2;
  const midpointLng = (startLng + endLng) / 2;

  // Let's count accidents within 2.5km of direct path
  const directAccidents = records.filter(r => {
    const distToMid = calculateHaversineDistance(r.latitude, r.longitude, midpointLat, midpointLng);
    return distToMid < 2.5;
  });

  const countEnRouteA = Math.max(2, directAccidents.length);
  const countEnRouteB = Math.max(0, Math.floor(directAccidents.length * 0.2));

  // Risk calculation: Route A risk based on accident count
  const scoreA = Math.min(95, 30 + countEnRouteA * 10);
  const riskLevelA = scoreA > 70 ? 'High' : (scoreA > 40 ? 'Medium' : 'Low');

  const scoreB = Math.min(35, 10 + countEnRouteB * 8);
  const riskLevelB = 'Low';

  // Generate paths
  const pathA: [number, number][] = [
    [startLat, startLng],
    [midpointLat + 0.003, midpointLng - 0.002],
    [endLat, endLng]
  ];

  const pathB: [number, number][] = [
    [startLat, startLng],
    [startLat - 0.015, startLng + 0.015], // detour away from hotspot
    [midpointLat - 0.018, midpointLng + 0.018],
    [endLat - 0.01, endLng + 0.01],
    [endLat, endLng]
  ];

  const routeA: RouteDetail = {
    id: 'ROUTE-A',
    name: 'National Highway / Direct Expressway',
    distance: parseFloat((calculateHaversineDistance(startLat, startLng, endLat, endLng) * 1.1).toFixed(1)),
    duration: Math.round(calculateHaversineDistance(startLat, startLng, endLat, endLng) * 1.1 * 3), // speed ~20km/h
    path: pathA,
    riskScore: scoreA,
    riskLevel: riskLevelA,
    safetyFactor: `${100 - scoreA}% Safe`,
    accidentsEnRouteCount: countEnRouteA
  };

  const routeB: RouteDetail = {
    id: 'ROUTE-B',
    name: 'Ring Road Bypass (Recommended)',
    distance: parseFloat((calculateHaversineDistance(startLat, startLng, endLat, endLng) * 1.4).toFixed(1)),
    duration: Math.round(calculateHaversineDistance(startLat, startLng, endLat, endLng) * 1.4 * 2.5), // less traffic, faster speed
    path: pathB,
    riskScore: scoreB,
    riskLevel: riskLevelB,
    safetyFactor: `${100 - scoreB}% Safe`,
    accidentsEnRouteCount: countEnRouteB
  };

  const recommendationReason = countEnRouteA > countEnRouteB
    ? `Route B is highly recommended. Although it adds ${Math.abs(routeB.distance - routeA.distance).toFixed(1)} km, it bypasses major accident hotspots including ${countEnRouteA} historically high-risk traffic zones, reducing overall risk levels from ${riskLevelA} to ${riskLevelB}.`
    : `Both routes have relatively low risk, but Route B offers wider lane bypasses and better lighting conditions.`;

  return {
    source,
    destination,
    routes: [routeB, routeA], // Recommended first
    recommendationReason
  };
}
